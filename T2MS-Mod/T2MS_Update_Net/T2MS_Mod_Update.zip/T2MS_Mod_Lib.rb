module TuAoThamSo
  class DatTuThuVienTool
    def initialize(tu_group)
      @tu_group = tu_group
      @ip = Sketchup::InputPoint.new
      @placed = false
    end
    def activate
      Sketchup.status_text = 'Di chuyển chuột tới vị trí cần đặt tủ -> Click chuột trái để đặt. Nhấn ESC để hủy.'
    end
    def deactivate(view)
      if !@placed && @tu_group && @tu_group.valid?
        @tu_group.erase!
      end
      view.invalidate
    end
    def onMouseMove(flags, x, y, view)
      @ip.pick(view, x, y)
      if @ip.valid? && @tu_group && @tu_group.valid?
        @tu_group.transformation = Geom::Transformation.new(@ip.position)
        view.invalidate
      end
    end
    def onLButtonDown(flags, x, y, view)
      @ip.pick(view, x, y)
      if @ip.valid? && @tu_group && @tu_group.valid?
        @tu_group.transformation = Geom::Transformation.new(@ip.position)
        @placed = true
        TuAoThamSo.dat_tu_hien_tai(@tu_group)
        Sketchup.active_model.selection.clear
        Sketchup.active_model.selection.add(@tu_group)
        TuAoThamSo.dong_bo_bang_voi_selection
        Sketchup.active_model.select_tool(nil)
      end
    end
    def onKeyDown(key, repeat, flags, view)
      Sketchup.active_model.select_tool(nil) if key == 27
    end
    def draw(view)
      @ip.draw(view) if @ip.valid?
    end
  end

  def self.nap_setting_tu_chon_vao_bang
    sel = Sketchup.active_model.selection
    tu = self.tim_tu_dang_chon || sel.grep(Sketchup::Group).first
    unless tu && tu.valid?
      UI.messagebox('Vui lòng click chọn một thùng tủ trên mô hình trước khi bấm Add Setting!')
      return
    end
    sub_grps = tu.entities.grep(Sketchup::Group).select(&:valid?)
    bb = tu.bounds
    dx = bb.width.to_mm.round(1)
    dy = bb.height.to_mm.round(1)
    real_cao = bb.depth.to_mm.round(1)
    canh_list = sub_grps.select { |g| g.name.to_s.downcase.include?('canh') }
    has_canh = !canh_list.empty?
    if dx < dy && dx <= 800
      real_dai, real_rong = dy, dx
    else
      real_dai, real_rong = dx, dy
    end
    if has_canh
      canh_thick = [canh_list.first.bounds.width.to_mm, canh_list.first.bounds.height.to_mm].min.round(1)
      canh_thick = 18.0 if canh_thick < 5 || canh_thick > 30
      real_rong = (real_rong - canh_thick).round(1) if real_rong > 400
      tu.set_attribute('TuAoConfig', 'co_canh', true)
      tu.set_attribute('TuAoConfig', 'canh_tu', true)
      tu.set_attribute('TuAoConfig', 'so_canh', canh_list.length)
    end
    tu.set_attribute('TuAoConfig', 'dai', real_dai)
    tu.set_attribute('TuAoConfig', 'cao', real_cao)
    tu.set_attribute('TuAoConfig', 'rong', real_rong)
    self.dat_tu_hien_tai(tu)
    sel.clear
    UI.start_timer(0.05, false) do
      if tu.valid?
        sel.add(tu)
        self.dong_bo_bang_voi_selection
      end
    end
  end

  def self.cap_nhat_va_tao_icon_tu
    sel = Sketchup.active_model.selection
    tu = self.tim_tu_dang_chon || sel.grep(Sketchup::Group).first
    unless tu && tu.valid?
      UI.messagebox('Vui lòng click chọn một thùng tủ trước khi bấm Cập nhật / Tạo Icon!')
      return
    end
    self.nap_setting_tu_chon_vao_bang
    cfg = self.lay_cau_hinh_thu_vien
    real_dirs = cfg['folders'].reject { |d| d.start_with?('__SEP__') }
    active_dir = Sketchup.read_default('T2MSMod', 'last_save_dir', real_dirs.first)
    if active_dir && Dir.exist?(active_dir)
      png_path = File.join(active_dir, "#{tu.name}.png")
      self.chup_thumbnail_chuan_tu(tu, png_path)
      self.tai_du_lieu_thu_vien_len_ui if @lib_dialog && @lib_dialog.visible?
      UI.messagebox("Đã cập nhật thông số & tạo Icon mới cho '#{tu.name}'!")
    end
  end
  def self.thu_muc_goc_mac_dinh
    require 'fileutils'
    dir = File.join(Sketchup.find_support_file("Plugins"), "T2MS_Mod_Library", "Mau_Mac_Dinh")
    FileUtils.mkdir_p(dir) unless Dir.exist?(dir)
    dir
  end

  def self.duong_dan_config_thu_vien
    File.join(File.dirname(self.thu_muc_goc_mac_dinh), 't2ms_lib_config.json')
  end

  def self.luu_cau_hinh_thu_vien(data)
    require 'json'
    File.write(self.duong_dan_config_thu_vien, JSON.pretty_generate(data), encoding: 'UTF-8')
  end

  def self.lay_cau_hinh_thu_vien
    require 'json'
    default_dir = self.thu_muc_goc_mac_dinh.tr('\\', '/')
    cfg_path = self.duong_dan_config_thu_vien
    data = File.exist?(cfg_path) ? (JSON.parse(File.read(cfg_path, encoding: 'UTF-8')) rescue {}) : {}
    dirs = data['folders'].is_a?(Array) ? data['folders'] : Array.new
    dirs.map! { |d| d.to_s.start_with?('__SEP__') ? d.to_s : d.to_s.tr('\\', '/') }
    dirs.uniq!
    dirs.select! { |d| d.start_with?('__SEP__') || File.directory?(d) }
    data['folders'] = dirs
    data['aliases'] ||= Hash.new
    data['favs'] ||= Array.new
    data['recents'] ||= Array.new
    self.luu_cau_hinh_thu_vien(data)
    data
  end

  def self.tai_du_lieu_thu_vien_len_ui(folder_key = nil)
    require 'json'
    return unless @lib_dialog && @lib_dialog.visible?
    cfg = self.lay_cau_hinh_thu_vien
    real_dirs = cfg['folders'].reject { |d| d.start_with?('__SEP__') }
    folder_key ||= Sketchup.read_default('T2MSMod', 'last_lib_dir', real_dirs.first)
    folder_key = (real_dirs.first || '__IN_MODEL__') if folder_key.to_s.empty? || (!folder_key.start_with?('__') && !real_dirs.include?(folder_key))
    aliases = cfg['aliases'] || Hash.new
    folder_items = cfg['folders'].map do |f|
      if f.start_with?('__SEP__')
        { 'is_sep' => true, 'path' => f }
      else
        cnt = Dir.glob(File.join(f, '*.skp')).length
        disp_name = aliases[f].to_s.empty? ? File.basename(f) : aliases[f]
        { 'is_sep' => false, 'name' => disp_name, 'path' => f, 'count' => cnt }
      end
    end
    payload = {
      'active_folder' => folder_key,
      'folders'       => folder_items,
      'fav_count'     => cfg['favs'].count { |p| File.exist?(p) },
      'recent_count'  => cfg['recents'].count { |p| File.exist?(p) },
      'items'         => self.quet_mau_trong_thu_muc(folder_key)
    }
    @lib_dialog.execute_script("renderThuVien(#{payload.to_json})")
  end

  def self.chup_thumbnail_chuan_tu(tu_group, png_path)
    model = Sketchup.active_model
    view  = model.active_view
    cam0  = view.camera
    o_eye = cam0.eye.clone
    o_tgt = cam0.target.clone
    o_up  = cam0.up.clone
    o_per = cam0.perspective?
    o_fov = o_per ? cam0.fov : cam0.height
    hidden_ents = Array.new
    model.active_entities.each do |e|
      if e != tu_group && e.visible?
        e.visible = false
        hidden_ents << e
      end
    end
    bb = tu_group.bounds
    center = bb.center
    dist = [bb.width, bb.height, bb.depth].max * 1.8
    eye = center + Geom::Vector3d.new(dist * 0.55, -dist * 0.85, dist * 0.35)
    view.camera = Sketchup::Camera.new(eye, center, Z_AXIS)
    view.zoom(tu_group)
    view.write_image({ :filename => png_path, :width => 300, :height => 300, :antialias => true, :transparent => false })
  ensure
    hidden_ents.each { |e| e.visible = true if e.valid? }
    if o_eye && o_tgt && o_up
      restored = Sketchup::Camera.new(o_eye, o_tgt, o_up, o_per)
      o_per ? (restored.fov = o_fov) : (restored.height = o_fov)
      view.camera = restored
    end
    view.invalidate
  end

  def self.luu_mau_vao_thu_vien(tu_group)
    require 'json'
    cfg = self.lay_cau_hinh_thu_vien
    real_dirs = cfg['folders'].reject { |d| d.start_with?('__SEP__') }
    active_dir = Sketchup.read_default('T2MSMod', 'last_save_dir', real_dirs.first)
    active_dir = real_dirs.first unless active_dir && Dir.exist?(active_dir)
    @save_dlg.close if @save_dlg && @save_dlg.visible?
    @save_dlg = UI::HtmlDialog.new({ :dialog_title => 'Lưu Mẫu Vào Thư Viện', :preferences_key => 'T2MSModSaveDialog', :scrollable => false, :resizable => false, :width => 360, :height => 210, :style => UI::HtmlDialog::STYLE_DIALOG })
    opts_list = (real_dirs + [active_dir]).uniq
    opts = opts_list.map { |f| sel = (f == active_dir) ? ' selected' : ''; "<option value=\"#{f}\" title=\"#{f}\"#{sel}>#{File.basename(f)}</option>" }.join
    html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:"Segoe UI",sans-serif;font-size:12px;padding:12px 14px;background:#f5f6f8;color:#222;margin:0}.row{margin-bottom:10px}.lbl{font-weight:600;margin-bottom:4px;display:block;color:#333}input,select{width:100%;height:28px;padding:2px 8px;border:1px solid #ccc;border-radius:4px;font-size:12px;box-sizing:border-box;background:#fff}.dir-row{display:flex;gap:6px}.dir-row select{flex:1}.btn-browse{width:34px;height:28px;border:1px solid #bbb;background:#fff;border-radius:4px;cursor:pointer;font-size:14px}.actions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}button.act{padding:6px 16px;border:none;border-radius:4px;font-weight:600;cursor:pointer;font-size:12px}.ok{background:#0078d7;color:#fff}.cancel{background:#e1e4e8;color:#333}</style></head><body><div class="row"><span class="lbl">Tên mẫu tủ:</span><input type="text" id="ten" value="' + tu_group.name + '"></div><div class="row"><span class="lbl">Thư mục lưu:</span><div class="dir-row"><select id="dir">' + opts + '</select><button type="button" class="btn-browse" onclick="sketchup.chonThuMucMoi()" title="Chọn thư mục khác">📁</button></div></div><div class="actions"><button type="button" class="act cancel" onclick="window.close()">Hủy</button><button type="button" class="act ok" onclick="luu()">Lưu Mẫu</button></div><script>function luu(){var t=document.getElementById("ten").value.trim();var d=document.getElementById("dir").value;if(t&&d)sketchup.xacNhanLuu(t,d)}function themOpt(p,n){var s=document.getElementById("dir");var o=document.createElement("option");o.value=p;o.text=n;o.title=p;o.selected=true;s.add(o)}</script></body></html>'
    @save_dlg.set_html(html)
    @save_dlg.add_action_callback('chonThuMucMoi') do |ctx|
      chosen = UI.select_directory(title: 'Chọn thư mục lưu mẫu T2MS-Mod')
      if chosen && Dir.exist?(chosen)
        chosen = chosen.tr('\\', '/')
        @save_dlg.execute_script("themOpt(#{chosen.to_json}, #{File.basename(chosen).to_json})")
      end
    end
    @save_dlg.add_action_callback('xacNhanLuu') do |ctx, ten_raw, folder|
      ten_mau = ten_raw.to_s.strip.gsub(/[^0-9A-Za-zÀ-ỹ _-]/, '_')
      next if ten_mau.empty? || !Dir.exist?(folder) || !tu_group.valid?
      Sketchup.write_default('T2MSMod', 'last_save_dir', folder)
      skp_path = File.join(folder, "#{ten_mau}.skp")
      png_path = File.join(folder, "#{ten_mau}.png")
      model = Sketchup.active_model
      model.start_operation('T2MS-Mod: Lưu mẫu thư viện', true)
      begin
        copy_tu = tu_group.copy
        copy_tu.transformation = Geom::Transformation.new
        tu_group.attribute_dictionaries&.each do |d|
          d.each { |k, v| copy_tu.set_attribute(d.name, k, v) }
          d.each { |k, v| copy_tu.definition.set_attribute(d.name, k, v) }
        end
        copy_tu.definition.save_as(skp_path)
        copy_tu.erase!
        self.chup_thumbnail_chuan_tu(tu_group, png_path)
        model.commit_operation
        @save_dlg.close
        UI.messagebox("Đã lưu mẫu '#{ten_mau}' thành công!")
        self.tai_du_lieu_thu_vien_len_ui if @lib_dialog && @lib_dialog.visible?
      rescue => e
        model.abort_operation
        UI.messagebox("Lỗi khi lưu mẫu: #{e.message}")
      end
    end
    @save_dlg.show
  end

  def self.quet_mau_trong_thu_muc(folder_key)
    require 'base64'
    cfg = self.lay_cau_hinh_thu_vien
    files = Array.new
    if folder_key == '__IN_MODEL__'
      Sketchup.active_model.entities.grep(Sketchup::Group).each do |g|
        next unless g.valid? && g.attribute_dictionary('TuAoConfig')
        files << { 'name' => g.name, 'path' => "in_model:#{g.entityID}", 'thumb' => '', 'fav' => false }
      end
      return files
    elsif folder_key == '__FAVORITES__'
      skp_list = cfg['favs'].select { |p| File.exist?(p) }
    elsif folder_key == '__RECENT__'
      skp_list = cfg['recents'].select { |p| File.exist?(p) }
    else
      dir = folder_key.to_s.tr('\\', '/')
      return Array.new unless File.directory?(dir)
      skp_list = Dir.children(dir).select { |f| f.downcase.end_with?('.skp') }.sort.map { |f| File.join(dir, f) }
    end
    skp_list.each do |skp|
      name = File.basename(skp, File.extname(skp))
      png  = skp.sub(/\.skp$/i, '.png')
      thumb_b64 = File.exist?(png) ? ('data:image/png;base64,' + Base64.strict_encode64(File.binread(png))) : ''
      files << { 'name' => name, 'path' => skp, 'thumb' => thumb_b64, 'fav' => cfg['favs'].include?(skp) }
    end
    files
  end

  def self.ghi_recent_thu_vien(skp_path)
    require 'json'
    return unless File.exist?(skp_path)
    cfg = self.lay_cau_hinh_thu_vien
    recents = cfg['recents'] || Array.new
    recents.delete(skp_path)
    recents.unshift(skp_path)
    cfg['recents'] = recents.first(20)
    File.write(File.join(File.dirname(self.thu_muc_goc_mac_dinh), 't2ms_lib_config.json'), JSON.pretty_generate(cfg), encoding: 'UTF-8')
  end

  def self.chen_hoac_thay_the_tu_thu_vien(skp_path, mode = 'insert')
    return if @is_updating
    model = Sketchup.active_model
    ents  = model.active_entities
    sel   = model.selection
    sel_ent = sel.first
    old_tu = self.tim_tu_dang_chon || ((sel_ent.is_a?(Sketchup::Group) || sel_ent.is_a?(Sketchup::ComponentInstance)) ? sel_ent : nil)
    if (mode == 'replace' || mode == 'replace_match') && (old_tu.nil? || !old_tu.valid?)
      UI.messagebox('Vui lòng click chọn một khối tủ hoặc khối hộp trong mô hình để thay thế!')
      return
    end
    @is_updating = true
    model.start_operation('T2MS-Mod: Chèn mẫu thư viện', true)
    begin
      if skp_path.start_with?('in_model:')
        eid = skp_path.split(':').last.to_i
        src_grp = ents.grep(Sketchup::Group).find { |g| g.entityID == eid }
        return unless src_grp
        new_grp = src_grp.copy
      else
        return unless File.exist?(skp_path)
        self.ghi_recent_thu_vien(skp_path)
        defn = model.definitions.load(skp_path)
        new_grp = ents.add_group
        inst = new_grp.entities.add_instance(defn, Geom::Transformation.new)
        inst.explode
        defn.attribute_dictionaries&.each do |d|
          d.each { |k, v| new_grp.set_attribute(d.name, k, v) }
        end
        if new_grp.entities.length == 1 && new_grp.entities.first.is_a?(Sketchup::Group) && new_grp.entities.first.attribute_dictionary('TuAoConfig')
          inner_tu = new_grp.entities.first
          inner_tu.attribute_dictionaries&.each { |d| d.each { |k, v| new_grp.set_attribute(d.name, k, v) } }
          inner_tu.explode
        end
        unless new_grp.attribute_dictionary('TuAoConfig')
          bb = new_grp.bounds
          new_grp.set_attribute('TuAoConfig', 'dai', bb.width.to_mm.round(1))
          new_grp.set_attribute('TuAoConfig', 'cao', bb.depth.to_mm.round(1))
          new_grp.set_attribute('TuAoConfig', 'rong', bb.height.to_mm.round(1))
          new_grp.set_attribute('TuAoConfig', 'day_van', 17.0)
        end
        new_grp.name = File.basename(skp_path, '.skp')
        c_val = new_grp.get_attribute('TuAoConfig', 'cao').to_f
        r_val = new_grp.get_attribute('TuAoConfig', 'rong').to_f
        if c_val > 0 && c_val < 1000 && r_val > 1500
          new_grp.set_attribute('TuAoConfig', 'cao', r_val)
          new_grp.set_attribute('TuAoConfig', 'rong', 600.0)
        end
      end
      if mode == 'place'
        Sketchup.active_model.select_tool(DatTuThuVienTool.new(new_grp))
      elsif mode == 'insert'
        new_grp.transformation = Geom::Transformation.new
      elsif mode == 'replace' && old_tu
        bb = old_tu.bounds
        new_grp.transformation = Geom::Transformation.new(bb.min)
        old_tu.erase!
      elsif mode == 'replace_match' && old_tu
        bb = old_tu.bounds
        dx = bb.width.to_mm.round(1)
        dy = bb.height.to_mm.round(1)
        dz = bb.depth.to_mm.round(1)
        rot_z = 0.degrees
        if dy > dx
          target_dai, target_cao, target_rong = dy, dz, dx
          rot_z = -90.degrees
        else
          target_dai, target_cao, target_rong = dx, dz, dy
        end
        full_params = self.lay_thong_so_tu_group(new_grp)
        if full_params
          full_params['dai']  = target_dai
          full_params['cao']  = target_cao
          full_params['rong'] = target_rong
          self.cap_nhat_tu(new_grp, full_params)
        end
        new_grp.transformation = Geom::Transformation.new(bb.min)
        if rot_z != 0
          new_grp.transform!(Geom::Transformation.rotation(bb.min, Z_AXIS, rot_z))
          nb = new_grp.bounds
          new_grp.transform!(Geom::Transformation.translation(bb.min - nb.min))
        end
        old_tu.erase!
      end
      self.dat_tu_hien_tai(new_grp)
      sel.clear
      sel.add(new_grp)
      model.commit_operation
      self.dong_bo_bang_voi_selection
    rescue => e
      model.abort_operation
      UI.messagebox('Lỗi chèn mẫu: ' + e.message)
    ensure
      @is_updating = false
    end
  end

  def self.mo_cua_so_thu_vien
  if @lib_dialog && @lib_dialog.visible?
    @lib_dialog.bring_to_front
    self.tai_du_lieu_thu_vien_len_ui
    return
  end

  @lib_dialog = UI::HtmlDialog.new({
    :dialog_title => "T2MS-Mod Thư viện",
    :preferences_key => "T2MSModLibraryDialog",
    :scrollable => true,
    :resizable => true,
    :width => 760,
    :height => 620,
    :style => UI::HtmlDialog::STYLE_DIALOG
  })

  @lib_dialog.set_html(self.tao_html_thu_vien)

  @lib_dialog.add_action_callback("libReady") do |ctx|
    self.tai_du_lieu_thu_vien_len_ui
  end

  @lib_dialog.add_action_callback("chonThuMucLib") do |ctx, folder_key|
    Sketchup.write_default("T2MSMod", "last_lib_dir", folder_key) unless folder_key.start_with?("__")
    self.tai_du_lieu_thu_vien_len_ui(folder_key)
  end

  @lib_dialog.add_action_callback('themThuMucLib') do |ctx|
      require 'json'
      chosen = UI.select_directory(title: 'Chọn thư mục thư viện mẫu T2MS-Mod')
      if chosen && Dir.exist?(chosen)
        chosen = chosen.tr('\\', '/')
        cfg = self.lay_cau_hinh_thu_vien
        dirs = cfg['folders']
        dirs << chosen unless dirs.include?(chosen)
        cfg['folders'] = dirs; self.luu_cau_hinh_thu_vien(cfg)
        Sketchup.write_default('T2MSMod', 'last_lib_dir', chosen)
        self.tai_du_lieu_thu_vien_len_ui(chosen)
      end
    end

    @lib_dialog.add_action_callback('xoaThuMucLib') do |ctx, folder_path|
      require 'json'
      target = folder_path.to_s.tr('\\', '/')
      next if target == self.thu_muc_goc_mac_dinh.tr('\\', '/')
      if UI.messagebox("Gỡ thư mục '#{File.basename(target)}' khỏi danh sách thư viện?\n(Dữ liệu gốc trên ổ cứng vẫn được giữ nguyên)", MB_YESNO) == IDYES
        cfg = self.lay_cau_hinh_thu_vien
        dirs = cfg['folders']
        dirs.delete(target)
        cfg['folders'] = dirs; self.luu_cau_hinh_thu_vien(cfg)
        Sketchup.write_default('T2MSMod', 'last_lib_dir', dirs.first)
        self.tai_du_lieu_thu_vien_len_ui(dirs.first)
      end
    end

    @lib_dialog.add_action_callback('lenhThuMucLib') do |ctx, act, target|
      require 'json'
      cfg = self.lay_cau_hinh_thu_vien
      dirs = cfg['folders']
      aliases = cfg['aliases'] || Hash.new
      cfg_path = File.join(File.dirname(self.thu_muc_goc_mac_dinh), 't2ms_lib_config.json')
      t_norm = target.to_s.start_with?('__SEP__') ? target.to_s : target.to_s.tr('\\', '/')
      case act
      when 'remove'
        def_dir = self.thu_muc_goc_mac_dinh.tr('\\', '/')
        if true
          dirs.reject! { |d| d.to_s.tr('\\', '/') == t_norm }
          aliases.delete(t_norm)
          cfg['folders'] = dirs
          cfg['aliases'] = aliases
          File.write(cfg_path, JSON.pretty_generate(cfg), encoding: 'UTF-8')
          first_real = dirs.find { |d| !d.start_with?('__SEP__') } || '__IN_MODEL__'
          Sketchup.write_default('T2MSMod', 'last_lib_dir', first_real)
          self.tai_du_lieu_thu_vien_len_ui(first_real)
        end
      when 'rename'
        next if t_norm.start_with?('__SEP__')
        cur_name = aliases[t_norm].to_s.empty? ? File.basename(t_norm) : aliases[t_norm]
        res = UI.inputbox(['Tên hiển thị mới:'], [cur_name], 'Đổi tên liên kết')
        if res && !res.at(0).to_s.strip.empty?
          aliases[t_norm] = res.at(0).to_s.strip
          cfg['aliases'] = aliases
          File.write(cfg_path, JSON.pretty_generate(cfg), encoding: 'UTF-8')
          self.tai_du_lieu_thu_vien_len_ui
        end
      when 'separator'
        idx = dirs.index { |d| d.to_s.tr('\\', '/') == t_norm }
        if idx
          dirs.insert(idx + 1, "__SEP__#{Time.now.to_i}_#{rand(999)}")
          cfg['folders'] = dirs
          File.write(cfg_path, JSON.pretty_generate(cfg), encoding: 'UTF-8')
          self.tai_du_lieu_thu_vien_len_ui
        end
      when 'explorer'
        system("explorer \"#{t_norm.tr('/', '\\')}\"") if Dir.exist?(t_norm)
      end
    end
    @lib_dialog.add_action_callback("toggleFavLib") do |ctx, skp_path|
    require 'json'
    next if skp_path.start_with?("in_model:")
    favs = JSON.parse(Sketchup.read_default("T2MSMod", "lib_favs", "")) rescue Array.new
    favs.include?(skp_path) ? favs.delete(skp_path) : (favs << skp_path)
    Sketchup.write_default("T2MSMod", "lib_favs", favs.to_json)
    self.tai_du_lieu_thu_vien_len_ui
  end

  @lib_dialog.add_action_callback("thucHienLenhMau") do |ctx, action, skp_path|
    case action
    when 'place' then self.chen_hoac_thay_the_tu_thu_vien(skp_path, 'place')
      when 'insert' then self.chen_hoac_thay_the_tu_thu_vien(skp_path, 'insert')
    when 'replace' then self.chen_hoac_thay_the_tu_thu_vien(skp_path, 'replace')
    when 'replace_match' then self.chen_hoac_thay_the_tu_thu_vien(skp_path, 'replace_match')
    when 'open' then Sketchup.open_file(skp_path) if File.exist?(skp_path)
    when 'delete'
      if File.exist?(skp_path) && UI.messagebox("Xóa vĩnh viễn mẫu '#{File.basename(skp_path, '.skp')}'?", MB_YESNO) == IDYES
        File.delete(skp_path) rescue nil
        png = skp_path.sub(/\.skp$/i, ".png")
        File.delete(png) if File.exist?(png)
        self.tai_du_lieu_thu_vien_len_ui
      end
    when 'explorer'
      system("explorer /select,\"#{skp_path.tr('/', '\\')}\"") if File.exist?(skp_path)
    end
  end

  @lib_dialog.show
end

def self.tao_html_thu_vien
    "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>\n*{box-sizing:border-box;user-select:none}body{margin:0;font-family:\"Segoe UI\",Tahoma,sans-serif;font-size:12.5px;color:#2b3440;background:#f8f9fb;display:flex;flex-direction:column;height:100vh;overflow:hidden}\n.topbar{height:42px;background:#fff;border-bottom:1px solid #e1e5eb;display:flex;align-items:center;padding:0 14px;gap:18px}\n.tab-btn{font-weight:600;font-size:12px;color:#5c6878;padding:11px 4px;border-bottom:2px solid transparent;cursor:pointer}.tab-btn.active{color:#0078d7;border-bottom-color:#0078d7}\n.toolbar{height:44px;background:#fff;border-bottom:1px solid #e1e5eb;display:flex;align-items:center;padding:0 12px;gap:10px}\n.mode-switch{display:flex;border:1px solid #cfd6df;border-radius:4px;overflow:hidden}.mode-switch div{padding:5px 14px;font-weight:600;font-size:12px;cursor:pointer;background:#fff;color:#4a5568}.mode-switch div.active{background:#0066cc;color:#fff}\n.search-wrap{flex:1;max-width:260px}.search-wrap input{width:100%;height:28px;border:1px solid #d0d7de;border-radius:4px;padding:2px 10px;font-size:12px;outline:none}\n.main-body{flex:1;display:flex;overflow:hidden}.sidebar{width:215px;background:#fff;border-right:1px solid #e1e5eb;display:flex;flex-direction:column;overflow-y:auto;padding:8px 0}\n.nav-item{display:flex;align-items:center;justify-content:space-between;padding:7px 14px;cursor:pointer;color:#374151;font-size:12.5px}.nav-item:hover{background:#f1f5f9}.nav-item.active{background:#e6f2ff;color:#0066cc;font-weight:600}\n.nav-left{display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nav-count{font-size:11.5px;color:#0078d7;font-weight:600}\n.folder-header{display:flex;align-items:center;justify-content:space-between;padding:6px 14px;margin-top:6px;border-top:1px solid #edf0f5;border-bottom:1px solid #edf0f5;margin-bottom:4px}\n.add-folder-btn{background:none;border:none;cursor:pointer;color:#0078d7;font-size:15px;font-weight:bold;padding:0 4px}\n.content{flex:1;padding:14px;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));grid-auto-rows:168px;gap:12px;align-content:start}\n.card{background:#fff;border:1.5px solid #e2e8f0;border-radius:6px;padding:6px;display:flex;flex-direction:column;align-items:center;position:relative;cursor:pointer}.card:hover{border-color:#60a5fa}.card.selected{border-color:#0078d7;background:#f0f7ff}\n.thumb-box{width:100%;height:126px;display:flex;align-items:center;justify-content:center;background:#f8fafc;border-radius:4px;overflow:hidden}.thumb-box img{max-width:100%;max-height:100%;object-fit:contain}\n.card-title{margin-top:6px;font-size:11.5px;font-weight:600;color:#1e293b;width:100%;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.fav-btn{position:absolute;top:6px;right:6px;width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,0.9);border:1px solid #cbd5e1;display:flex;align-items:center;justify-content:center;font-size:13px;color:#64748b;cursor:pointer}.fav-btn.is-fav{color:#e11d48;border-color:#fecdd3;background:#fff1f2}\n.ctx-menu{display:none;position:fixed;z-index:9999;width:205px;background:#fff;border:1px solid #d1d5db;border-radius:6px;box-shadow:0 8px 20px rgba(0,0,0,0.16);padding:5px 0}\n.ctx-item{display:flex;align-items:center;gap:10px;padding:7px 14px;font-size:12.5px;color:#1f2937;cursor:pointer}.ctx-item:hover{background:#f1f5f9;color:#0066cc}.ctx-item.danger:hover{background:#fef2f2;color:#dc2626}.ctx-sep{height:1px;background:#e5e7eb;margin:4px 0}\n.empty-msg{grid-column:1/-1;text-align:center;color:#94a3b8;margin-top:50px;font-size:13px}\n</style></head>\n<body onclick=\"anContextMenu()\">\n<div class=\"topbar\"><div class=\"tab-btn active\">MODEL</div><div class=\"tab-btn\">MATERIAL</div></div>\n<div class=\"toolbar\"><div class=\"mode-switch\"><div class=\"active\">Local</div><div>Online</div></div><div class=\"search-wrap\"><input type=\"text\" id=\"lib_search\" placeholder=\"Find...\" oninput=\"locMau()\"></div></div>\n<div class=\"main-body\"><div class=\"sidebar\">\n<div class=\"nav-item\" id=\"nav___IN_MODEL__\" onclick=\"chonMuc(this.dataset.k)\" data-k=\"__IN_MODEL__\"><div class=\"nav-left\">📦 <span>In Model</span></div></div>\n<div class=\"nav-item\" id=\"nav___FAVORITES__\" onclick=\"chonMuc(this.dataset.k)\" data-k=\"__FAVORITES__\"><div class=\"nav-left\">♡ <span>Favorites</span></div><span class=\"nav-count\" id=\"cnt_fav\">0</span></div>\n<div class=\"nav-item\" id=\"nav___RECENT__\" onclick=\"chonMuc(this.dataset.k)\" data-k=\"__RECENT__\"><div class=\"nav-left\">🕒 <span>Recent</span></div><span class=\"nav-count\" id=\"cnt_recent\">0</span></div>\n<div class=\"folder-header\"><button class=\"add-folder-btn\" onclick=\"sketchup.sortThuMucLib()\" title=\"Sort\" style=\"color:#475569;font-size:13px\">⌃</button><button class=\"add-folder-btn\" onclick=\"sketchup.themThuMucLib()\" title=\"Thêm thư mục\">+📁</button></div><div id=\"folder_list\"></div>\n</div><div class=\"content\" id=\"grid_items\"></div></div>\n<div class=\"ctx-menu\" id=\"folder_ctx_menu\">\n<div class=\"ctx-item\" data-act=\"rename\" onclick=\"chayLenhFolderCtx(this.dataset.act)\">✎ <span>Rename</span></div>\n<div class=\"ctx-item danger\" data-act=\"remove\" onclick=\"chayLenhFolderCtx(this.dataset.act)\">🗑 <span>Remove</span></div><div class=\"ctx-sep\"></div>\n<div class=\"ctx-item\" data-act=\"separator\" onclick=\"chayLenhFolderCtx(this.dataset.act)\">⇕ <span>Add a Separator</span></div>\n<div class=\"ctx-item\" data-act=\"explorer\" onclick=\"chayLenhFolderCtx(this.dataset.act)\">↗ <span>View in Explorer</span></div></div>\n<div class=\"ctx-menu\" id=\"ctx_menu\">\n<div class=\"ctx-item\" onclick=\"chonTatCaCard()\">✓ <span>Check All</span></div><div class=\"ctx-sep\"></div>\n<div class=\"ctx-item\" data-act=\"insert\" onclick=\"chayLenhCtx(this.dataset.act)\">📥 <span>Insert at Origin</span></div>\n<div class=\"ctx-item\" data-act=\"replace\" onclick=\"chayLenhCtx(this.dataset.act)\">🔄 <span>Replace Selected</span></div>\n<div class=\"ctx-item\" data-act=\"replace_match\" onclick=\"chayLenhCtx(this.dataset.act)\">⤢ <span>Replace &amp; Match</span></div><div class=\"ctx-sep\"></div>\n<div class=\"ctx-item\" data-act=\"open\" onclick=\"chayLenhCtx(this.dataset.act)\">📄 <span>Open file</span></div>\n<div class=\"ctx-item danger\" data-act=\"delete\" onclick=\"chayLenhCtx(this.dataset.act)\">🗑 <span>Delete</span></div><div class=\"ctx-sep\"></div>\n<div class=\"ctx-item\" data-act=\"explorer\" onclick=\"chayLenhCtx(this.dataset.act)\">↗ <span>View in Explorer</span></div></div>\n<script>\nvar ALL_ITEMS = new Array(), CTX_PATH = \"\", CTX_FOLDER = \"\";\nfunction chayLenhFolderCtx(a){ anContextMenu(); if(CTX_FOLDER) sketchup.lenhThuMucLib(a, CTX_FOLDER); }\nfunction renderThuVien(data){\n  ALL_ITEMS = data.items || new Array();\n  document.getElementById(\"cnt_fav\").innerText = data.fav_count || 0;\n  document.getElementById(\"cnt_recent\").innerText = data.recent_count || 0;\n  document.querySelectorAll(\".nav-item\").forEach(function(el){el.classList.remove(\"active\")});\n  var sysNav = document.getElementById(\"nav_\" + data.active_folder); if(sysNav) sysNav.classList.add(\"active\");\n  var fList = document.getElementById(\"folder_list\"); fList.innerHTML = \"\";\n  (data.folders || new Array()).forEach(function(f){\n    if(f.is_sep){ var sep = document.createElement(\"div\"); sep.style.cssText = \"height:1px;background:#e2e8f0;margin:6px 12px;cursor:pointer\"; sep.oncontextmenu = function(e){ e.preventDefault(); e.stopPropagation(); CTX_FOLDER = f.path; var fm = document.getElementById(\"folder_ctx_menu\"); fm.style.display = \"block\"; fm.style.left = e.clientX + \"px\"; fm.style.top = e.clientY + \"px\"; }; fList.appendChild(sep); return; }\n    var div = document.createElement(\"div\"); div.className = \"nav-item\" + (f.path === data.active_folder ? \" active\" : \"\"); div.title = f.path;\n    div.onclick = function(){ chonMuc(f.path); };\n    div.oncontextmenu = function(e){ e.preventDefault(); e.stopPropagation(); anContextMenu(); CTX_FOLDER = f.path; var fm = document.getElementById(\"folder_ctx_menu\"); fm.style.display = \"block\"; fm.style.left = Math.min(e.clientX, window.innerWidth - 210) + \"px\"; fm.style.top = Math.min(e.clientY, window.innerHeight - 180) + \"px\"; };\n    var cntHtml = (f.count > 0) ? \"<span class=\\\"nav-count\\\">\" + f.count + \"</span>\" : \"\";\n    div.innerHTML = \"<div class=\\\"nav-left\\\"><span>\" + f.name + \"</span></div>\" + cntHtml;\n    fList.appendChild(div);\n  }); locMau();\n}\nfunction locMau(){\n  var kw = document.getElementById(\"lib_search\").value.toLowerCase().trim();\n  var grid = document.getElementById(\"grid_items\"); grid.innerHTML = \"\";\n  var filtered = ALL_ITEMS.filter(function(it){ return it.name.toLowerCase().indexOf(kw) !== -1; });\n  if(filtered.length === 0){ grid.innerHTML = \"<div class=\\\"empty-msg\\\">Chưa có mẫu tủ nào trong thư mục này.<br>Hãy chọn tủ ở mô hình và bấm <b>Lưu Mẫu Vào Thư Viện</b>!</div>\"; return; }\n  filtered.forEach(function(it){\n    var card = document.createElement(\"div\"); card.className = \"card\";\n    card.onclick = function(e){ e.stopPropagation(); document.querySelectorAll(\".card\").forEach(function(c){c.classList.remove(\"selected\")}); card.classList.add(\"selected\"); sketchup.thucHienLenhMau(\"place\", it.path); };\n    card.ondblclick = function(){ sketchup.thucHienLenhMau(\"insert\", it.path); };\n    card.oncontextmenu = function(e){ e.preventDefault(); e.stopPropagation(); document.querySelectorAll(\".card\").forEach(function(c){c.classList.remove(\"selected\")}); card.classList.add(\"selected\"); CTX_PATH = it.path; var m = document.getElementById(\"ctx_menu\"); m.style.display = \"block\"; m.style.left = Math.min(e.clientX, window.innerWidth - 215) + \"px\"; m.style.top = Math.min(e.clientY, window.innerHeight - 260) + \"px\"; };\n    var imgHtml = it.thumb ? \"<img src=\\\"\" + it.thumb + \"\\\">\" : \"<span style=\\\"font-size:32px;color:#94a3b8\\\">🗄️</span>\";\n    var favCls = it.fav ? \"fav-btn is-fav\" : \"fav-btn\"; var favChar = it.fav ? \"♥\" : \"♡\";\n    var favBtn = document.createElement(\"div\"); favBtn.className = favCls; favBtn.innerText = favChar; favBtn.onclick = function(e){ e.stopPropagation(); sketchup.toggleFavLib(it.path); };\n    card.innerHTML = \"<div class=\\\"thumb-box\\\">\" + imgHtml + \"</div><div class=\\\"card-title\\\">\" + it.name + \"</div>\";\n    card.insertBefore(favBtn, card.firstChild);\n    grid.appendChild(card);\n  });\n}\nfunction chonMuc(k){ sketchup.chonThuMucLib(k); }\nfunction anContextMenu(){ document.getElementById(\"ctx_menu\").style.display = \"none\"; var fm = document.getElementById(\"folder_ctx_menu\"); if(fm) fm.style.display = \"none\"; }\nfunction chonTatCaCard(){ document.querySelectorAll(\".card\").forEach(function(c){c.classList.add(\"selected\")}); }\nfunction chayLenhCtx(a){ anContextMenu(); if(CTX_PATH) sketchup.thucHienLenhMau(a, CTX_PATH); }\nwindow.onload = function(){ sketchup.libReady(); };\n</script></body></html>"
  end
end
