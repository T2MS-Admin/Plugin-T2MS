require_relative 'T2MS_Mod_Lib'
module TuAoThamSo
  @dialog = nil
  @current_tu_group = nil
  @is_updating = false

  def self.reload_plugin
    load __FILE__
    puts "Da nap lai T2MS-Mod thanh cong!"
  end

  class ChonTamTool
    def initialize(tu_group = nil, tam_ban_dau = nil)
      @tu_group = tu_group
      @hovered_tam = nil
      @selected_base_name = nil
      @default_day = 17.0

      if @tu_group && tam_ban_dau && tam_ban_dau.valid? && tam_ban_dau.attribute_dictionary('TamConfig')
        @selected_base_name = tam_ban_dau.get_attribute('TamConfig', 'base_name') || tam_ban_dau.name
        @default_day = (tam_ban_dau.get_attribute('TamConfig', 'default_day') || 17.0).to_f
      end
    end

    def activate
      if @tu_group && @selected_base_name
        chuoi = TuAoThamSo.lay_chuoi_hien_tai_cua_tam(@tu_group, @selected_base_name, @default_day)
        Sketchup.vcb_label = "#{@selected_base_name}:"
        Sketchup.vcb_value = chuoi
        Sketchup.status_text = "Đang chọn #{@selected_base_name}. Gõ độ dày/lớp + Enter, hoặc nhấn DELETE để xóa tấm. ESC thoát."
      else
        Sketchup.status_text = "Click vào tấm ván bất kỳ (kể cả đợt chia khoang) để chỉnh độ dày hoặc nhấn DELETE để xóa. ESC thoát."
        Sketchup.vcb_label = "Độ dày / Lớp:"
        Sketchup.vcb_value = ""
      end
    end

    def deactivate(view)
      view.invalidate
      TuAoThamSo.thong_bao_thoat_chinh_tam
    end

    def enableVCB?
      return true
    end

    def onMouseMove(flags, x, y, view)
      ph = view.pick_helper
      ph.do_pick(x, y)
      _, tam_moi = tim_tu_va_tam(ph)
      if tam_moi != @hovered_tam
        @hovered_tam = tam_moi
        view.invalidate
      end
    end

    def onLButtonDown(flags, x, y, view)
      ph = view.pick_helper
      ph.do_pick(x, y)
      tu, tam = tim_tu_va_tam(ph)
      if tu && tam
        @tu_group = tu
        TuAoThamSo.dat_tu_hien_tai(tu)
        @selected_base_name = tam.get_attribute('TamConfig', 'base_name') || tam.name
        @default_day = (tam.get_attribute('TamConfig', 'default_day') || @tu_group.get_attribute('TuAoConfig', 'day_van', 17.0)).to_f

        Sketchup.active_model.selection.clear
        Sketchup.active_model.selection.add(tam)

        chuoi_hien_tai = TuAoThamSo.hien_bang_chi_tiet_tam(@tu_group, tam)
        Sketchup.vcb_label = "#{@selected_base_name}:"
        Sketchup.vcb_value = chuoi_hien_tai.to_s
        Sketchup.status_text = "Đang chọn #{@selected_base_name}. Gõ số + Enter, hoặc nhấn DELETE để xóa luôn tấm này."
      end
    end

    def onUserText(text, view)
      if @selected_base_name.nil? || @tu_group.nil? || !@tu_group.valid?
        sel = Sketchup.active_model.selection
        if !sel.empty? && sel.first.is_a?(Sketchup::Group) && sel.first.attribute_dictionary('TamConfig')
          @selected_base_name = sel.first.get_attribute('TamConfig', 'base_name')
          @tu_group = TuAoThamSo.tim_tu_dang_chon
        end
      end

      return unless @selected_base_name && @tu_group && @tu_group.valid?
      raw = text.to_s.strip
      return if raw.empty?

      parts = raw.split('/').map { |s| s.strip.gsub(',', '.').to_f }.select { |n| n >= 0 }
      return if parts.empty?

      lop = parts.length
      tong_day = parts.sum

      TuAoThamSo.ap_dung_thong_so_tam_tu_vcb(@tu_group, @selected_base_name, tong_day, lop, parts)

      chuoi_moi = parts.map { |v| (v.to_i == v) ? v.to_i : v }.join('/')
      Sketchup.vcb_label = "#{@selected_base_name}:"
      Sketchup.vcb_value = chuoi_moi
      view.invalidate
    end

    def onKeyDown(key, repeat, flags, view)
      if key == 27
        Sketchup.active_model.select_tool(nil)
      elsif key == 46 || key == 8
        if @selected_base_name && @tu_group && @tu_group.valid?
          TuAoThamSo.xoa_tam_dang_chon(@tu_group, @selected_base_name)
          @selected_base_name = nil
          @hovered_tam = nil
          view.invalidate
        end
      end
    end

    def draw(view)
      if @hovered_tam && @hovered_tam.valid?
        bb = @hovered_tam.bounds
        p0 = bb.corner(0); p1 = bb.corner(1); p2 = bb.corner(2); p3 = bb.corner(3)
        p4 = bb.corner(4); p5 = bb.corner(5); p6 = bb.corner(6); p7 = bb.corner(7)
        pts = [
          p0, p1, p1, p3, p3, p2, p2, p0,
          p4, p5, p5, p7, p7, p6, p6, p4,
          p0, p4, p1, p5, p2, p6, p3, p7
        ]
        view.drawing_color = Sketchup::Color.new(0, 120, 215, 220)
        view.line_width = 3
        view.draw(GL_LINES, pts)
      end
    end

    private

    def tim_tu_va_tam(ph)
      ph.count.times do |i|
        path = ph.path_at(i)
        next unless path
        tu_idx = path.index { |e| e.is_a?(Sketchup::Group) && e.attribute_dictionary('TuAoConfig') }
        if tu_idx && path[tu_idx + 1] && path[tu_idx + 1].is_a?(Sketchup::Group)
          return [path[tu_idx], path[tu_idx + 1]] unless path[tu_idx + 1].name == 'Giao_Cat_Mo'
        end
      end
      [nil, nil]
    end
  end

  class ChiaKhoangTool
    ALIGN_MODES = ['duoi', 'giua', 'tren'].freeze unless defined?(ALIGN_MODES)

    def initialize(tu_group = nil)
      @tu_group = tu_group
      @hovered_region = nil
      @selected_region = nil
      @preview_data = nil
      @align_idx = 0
    end

    def set_preview(data)
      v_empty = data['vach_expr'].to_s.strip.empty?
      d_empty = data['dot_expr'].to_s.strip.empty?
      @preview_data = (v_empty && d_empty) ? nil : data
      if @preview_data
        @preview_data['align_mode'] = ALIGN_MODES[@align_idx]
      end
      Sketchup.active_model.active_view.invalidate
    end

    def clear_preview
      @preview_data = nil
      Sketchup.active_model.active_view.invalidate
    end

    def clear_selection
      @selected_region = nil
      @preview_data = nil
      Sketchup.active_model.active_view.invalidate
    end

    def current_region
      @selected_region
    end

    def activate
      Sketchup.status_text = "Rê chuột chọn khoang -> Click chọn -> Nhập số đợt -> Nhấn TAB đổi vị trí (Dưới / Giữa / Trên) -> Enter áp dụng."
    end

    def deactivate(view)
      view.invalidate
      TuAoThamSo.thong_bao_thoat_chia_khoang
    end

    def onMouseMove(flags, x, y, view)
      reg = tim_vung_duoi_chuot(x, y, view)
      if reg != @hovered_region
        @hovered_region = reg
        view.invalidate
      end
    end

    def onLButtonDown(flags, x, y, view)
      reg = tim_vung_duoi_chuot(x, y, view)
      if reg
        @selected_region = reg
        @hovered_region = reg
        @tu_group = reg[:tu_group]
        @preview_data = nil
        @align_idx = 0
        TuAoThamSo.dat_tu_hien_tai(@tu_group)
        TuAoThamSo.mo_bang_chia_cho_vung(@tu_group, reg)
        view.invalidate
      end
    end

    def onKeyDown(key, repeat, flags, view)
      if key == 27
        Sketchup.active_model.select_tool(nil)
      elsif key == 9
        @align_idx = (@align_idx + 1) % ALIGN_MODES.length
        mode = ALIGN_MODES[@align_idx]
        if @preview_data
          @preview_data['align_mode'] = mode
        end
        ten_che_do = case mode
                     when 'duoi' then "Dưới / Trái tấm"
                     when 'giua' then "Giữa tim tấm"
                     when 'tren' then "Trên / Phải tấm"
                     end
        Sketchup.status_text = "Vị trí chuẩn tấm chia: #{ten_che_do} (Nhấn TAB để đổi tiếp, ENTER để áp dụng)"
        view.invalidate
        return true
      elsif key == 13 && @preview_data && @selected_region
        @preview_data['align_mode'] = ALIGN_MODES[@align_idx]
        TuAoThamSo.chot_ap_dung_preview(@selected_region[:tu_group], @selected_region[:path], @preview_data)
        @preview_data = nil
        view.invalidate
      end
    end
    def draw(view)
      if @selected_region && @selected_region[:tu_group].valid?
        ve_khoi_khoang(view, @selected_region, Sketchup::Color.new(255, 242, 130, 80), Sketchup::Color.new(230, 160, 0, 220), 2)
      end

      if @hovered_region && @hovered_region[:tu_group].valid?
        same_sel = (@selected_region && @selected_region[:tu_group] == @hovered_region[:tu_group] && @selected_region[:path] == @hovered_region[:path])
        unless same_sel
          ve_khoi_khoang(view, @hovered_region, Sketchup::Color.new(144, 238, 144, 75), Sketchup::Color.new(46, 160, 67, 220), 2)
        end
      end

      ve_mo_phong_chia(view) if @preview_data && @selected_region && @selected_region[:tu_group].valid?
    end

    private

    def ve_khoi_khoang(view, reg, fill_color, line_color, width)
      tu = reg[:tu_group]
      return unless tu && tu.valid?
      tr = tu.transformation

      x1 = reg[:x1] + 0.5.mm; x2 = reg[:x2] - 0.5.mm
      y1 = reg[:y1] + 0.5.mm; y2 = reg[:y2] - 0.5.mm
      z1 = reg[:z1] + 0.5.mm; z2 = reg[:z2] - 0.5.mm
      return if x2 <= x1 || y2 <= y1 || z2 <= z1

      p0 = Geom::Point3d.new(x1, y1, z1).transform(tr)
      p1 = Geom::Point3d.new(x2, y1, z1).transform(tr)
      p2 = Geom::Point3d.new(x2, y2, z1).transform(tr)
      p3 = Geom::Point3d.new(x1, y2, z1).transform(tr)
      p4 = Geom::Point3d.new(x1, y1, z2).transform(tr)
      p5 = Geom::Point3d.new(x2, y1, z2).transform(tr)
      p6 = Geom::Point3d.new(x2, y2, z2).transform(tr)
      p7 = Geom::Point3d.new(x1, y2, z2).transform(tr)

      view.drawing_color = fill_color
      view.draw(GL_QUADS, [p0, p1, p2, p3, p4, p7, p6, p5, p3, p2, p6, p7, p0, p3, p7, p4, p1, p5, p6, p2])

      view.drawing_color = line_color
      view.line_width = width
      view.draw(GL_LINES, [p0, p1, p1, p5, p5, p4, p4, p0, p3, p2, p2, p6, p6, p7, p7, p3, p0, p3, p1, p2, p4, p7, p5, p6])
    end

def ve_mo_phong_chia(view)
  tu = @selected_region[:tu_group]
  tr = tu.transformation
  r  = @selected_region
  day_van = (tu.get_attribute('TuAoConfig', 'day_van', 17.0)).to_f.mm
  align_mode = ALIGN_MODES[@align_idx] || 'duoi'

  vach_expr    = @preview_data['vach_expr'].to_s.strip
  vach_uu_tien = @preview_data['vach_uu_tien'] || 'trai'
  vach_lui     = @preview_data['vach_lui'].to_f.mm

  dot_expr     = @preview_data['dot_expr'].to_s.strip
  dot_uu_tien  = @preview_data['dot_uu_tien'] || 'duoi'
  dot_lui      = @preview_data['dot_lui'].to_f.mm

  rong_vung = r[:x2] - r[:x1]
  cao_vung  = r[:z2] - r[:z1]
  sau_vung  = r[:y2] - r[:y1]

  fill_glass = Sketchup::Color.new(175, 220, 245, 55)
  line_solid = Sketchup::Color.new(45, 75, 115, 235)
  line_dash  = Sketchup::Color.new(75, 105, 145, 180)

  if !vach_expr.empty? && rong_vung > day_van && sau_vung > vach_lui
    dao_v = (vach_uu_tien == 'phai')
    vi_tri_v = TuAoThamSo.tinh_vi_tri_chia_o(rong_vung, day_van, vach_expr, dao_v, align_mode)
    z_line = r[:z1] + cao_vung * 0.65

    ve_duong_giong_xuyen_khoang(view, tr, r[:x1], r[:y1], z_line, r[:x2], r[:y1], z_line)

    solid_face = case align_mode
                 when 'giua' then :none
                 when 'tren' then (dao_v ? :x_min : :x_max)
                 else (dao_v ? :x_max : :x_min)
                 end

    cur_x = r[:x1]
    vi_tri_v.each do |dx_pos|
      vx = r[:x1] + dx_pos
      ve_hop_kinh_mo(view, tr, vx, r[:y1] + vach_lui, r[:z1], day_van, sau_vung - vach_lui, cao_vung, fill_glass, line_solid, line_dash, solid_face)
      ve_kich_thuoc_vien_thuoc(view, tr, cur_x, r[:y1], z_line, vx, r[:y1], z_line)
      cur_x = vx + day_van
    end
    ve_kich_thuoc_vien_thuoc(view, tr, cur_x, r[:y1], z_line, r[:x2], r[:y1], z_line) unless vi_tri_v.empty?
  end

  if !dot_expr.empty? && cao_vung > day_van && sau_vung > dot_lui
    dao_d = (dot_uu_tien == 'tren')
    vi_tri_d = TuAoThamSo.tinh_vi_tri_chia_o(cao_vung, day_van, dot_expr, dao_d, align_mode)
    x_line = r[:x1] + rong_vung * 0.62

    ve_duong_giong_xuyen_khoang(view, tr, x_line, r[:y1], r[:z1], x_line, r[:y1], r[:z2])

    solid_face = case align_mode
                 when 'giua' then :none
                 when 'tren' then (dao_d ? :z_min : :z_max)
                 else (dao_d ? :z_max : :z_min)
                 end

    cur_z = r[:z1]
    vi_tri_d.each do |dz_pos|
      dz = r[:z1] + dz_pos
      ve_hop_kinh_mo(view, tr, r[:x1], r[:y1] + dot_lui, dz, rong_vung, sau_vung - dot_lui, day_van, fill_glass, line_solid, line_dash, solid_face)
      ve_kich_thuoc_vien_thuoc(view, tr, x_line, r[:y1], cur_z, x_line, r[:y1], dz)
      cur_z = dz + day_van
    end
    ve_kich_thuoc_vien_thuoc(view, tr, x_line, r[:y1], cur_z, x_line, r[:y1], r[:z2]) unless vi_tri_d.empty?
  end
end

    def ve_hop_kinh_mo(view, tr, x, y, z, dx, dy, dz, fill_col, line_solid, line_dash, solid_face = :z_min)
      p0 = Geom::Point3d.new(x, y, z).transform(tr)
      p1 = Geom::Point3d.new(x + dx, y, z).transform(tr)
      p2 = Geom::Point3d.new(x + dx, y + dy, z).transform(tr)
      p3 = Geom::Point3d.new(x, y + dy, z).transform(tr)
      p4 = Geom::Point3d.new(x, y, z + dz).transform(tr)
      p5 = Geom::Point3d.new(x + dx, y, z + dz).transform(tr)
      p6 = Geom::Point3d.new(x + dx, y + dy, z + dz).transform(tr)
      p7 = Geom::Point3d.new(x, y + dy, z + dz).transform(tr)

      view.drawing_color = fill_col
      view.draw(GL_QUADS, [p0, p1, p5, p4, p1, p2, p6, p5, p2, p3, p7, p6, p3, p0, p4, p7, p4, p5, p6, p7, p0, p3, p2, p1])

      all_edges = [
        [p0, p1], [p1, p2], [p2, p3], [p3, p0],
        [p4, p5], [p5, p6], [p6, p7], [p7, p4],
        [p0, p4], [p1, p5], [p2, p6], [p3, p7]
      ]

      solid_edges = case solid_face
                    when :z_min then [[p0, p1], [p1, p2], [p2, p3], [p3, p0]]
                    when :z_max then [[p4, p5], [p5, p6], [p6, p7], [p7, p4]]
                    when :x_min then [[p0, p3], [p3, p7], [p7, p4], [p4, p0]]
                    when :x_max then [[p1, p2], [p2, p6], [p6, p5], [p5, p1]]
                    else []
                    end

      dash_edges = all_edges - solid_edges

      unless dash_edges.empty?
        view.drawing_color = line_dash
        view.line_width = 1
        view.line_stipple = "-"
        view.draw(GL_LINES, dash_edges.flatten)
        view.line_stipple = ""
      end

      unless solid_edges.empty?
        view.drawing_color = line_solid
        view.line_width = 2
        view.draw(GL_LINES, solid_edges.flatten)
      end
    end

    def ve_duong_giong_xuyen_khoang(view, tr, x1, y1, z1, x2, y2, z2)
      pt1 = Geom::Point3d.new(x1, y1, z1).transform(tr)
      pt2 = Geom::Point3d.new(x2, y2, z2).transform(tr)
      view.drawing_color = Sketchup::Color.new(80, 95, 115, 160)
      view.line_width = 1
      view.line_stipple = "."
      view.draw(GL_LINES, [pt1, pt2])
      view.line_stipple = ""
    end

    def ve_kich_thuoc_vien_thuoc(view, tr, x1, y1, z1, x2, y2, z2)
      pt1 = Geom::Point3d.new(x1, y1, z1).transform(tr)
      pt2 = Geom::Point3d.new(x2, y2, z2).transform(tr)
      dist_mm = pt1.distance(pt2).to_mm.round(1)
      return if dist_mm <= 0

      scr1 = view.screen_coords(pt1)
      scr2 = view.screen_coords(pt2)

      line_col = Sketchup::Color.new(45, 58, 82, 245)
      view.drawing_color = line_col
      view.line_width = 2
      view.draw2d(GL_LINES, [scr1, scr2])

      [scr1, scr2].each do |sc|
        ve_vong_tron_2d(view, sc.x, sc.y, 4.0, Sketchup::Color.new(255, 255, 255, 255), line_col)
      end

      mid_x = (scr1.x + scr2.x) / 2.0
      mid_y = (scr1.y + scr2.y) / 2.0
      label_txt = format('%.1f', dist_mm)

      box_w = [label_txt.length * 7.2 + 12, 38].max
      box_h = 17.0
      ve_khung_vien_thuoc_2d(view, mid_x, mid_y, box_w, box_h, Sketchup::Color.new(255, 255, 255, 245), line_col)

      view.draw_text(
        Geom::Point3d.new(mid_x - box_w / 2.0 + 6, mid_y - 7.5, 0),
        label_txt,
        :size => 10,
        :bold => true,
        :color => Sketchup::Color.new(25, 30, 40)
      )
    end

    def ve_vong_tron_2d(view, cx, cy, r, fill_col, border_col)
      segs = 16
      pts = []
      segs.times do |i|
        ang = 2.0 * Math::PI * i / segs
        pts << Geom::Point3d.new(cx + r * Math.cos(ang), cy + r * Math.sin(ang), 0)
      end
      view.drawing_color = fill_col
      view.draw2d(GL_POLYGON, pts)
      view.drawing_color = border_col
      view.line_width = 1.5
      view.draw2d(GL_LINE_LOOP, pts)
    end

    def ve_khung_vien_thuoc_2d(view, cx, cy, w, h, fill_col, border_col)
      r = h / 2.0
      hw = [w / 2.0 - r, 0].max
      segs = 10
      pts = []
      (0..segs).each do |i|
        ang = -Math::PI / 2.0 + Math::PI * i / segs
        pts << Geom::Point3d.new(cx + hw + r * Math.cos(ang), cy + r * Math.sin(ang), 0)
      end
      (0..segs).each do |i|
        ang = Math::PI / 2.0 + Math::PI * i / segs
        pts << Geom::Point3d.new(cx - hw + r * Math.cos(ang), cy + r * Math.sin(ang), 0)
      end
      view.drawing_color = fill_col
      view.draw2d(GL_POLYGON, pts)
      view.drawing_color = border_col
      view.line_width = 1.5
      view.draw2d(GL_LINE_LOOP, pts)
    end

    def tim_vung_duoi_chuot(x, y, view)
      ray = view.pickray(x, y)
      return nil unless ray.is_a?(Array) && ray.length >= 2
      origin = ray.first
      dir    = ray.last
      return nil unless origin && dir

      candidates = Array.new
      tu_hien_tai = @tu_group && @tu_group.valid? ? @tu_group : TuAoThamSo.tim_tu_dang_chon
      candidates << tu_hien_tai if tu_hien_tai
      Sketchup.active_model.active_entities.grep(Sketchup::Group).each do |g|
        candidates << g if g.attribute_dictionary('TuAoConfig') && !candidates.include?(g)
      end

      best_reg = nil
      best_dist = Float::INFINITY

      candidates.each do |tu|
        tr = tu.transformation
        inv_tr = tr.inverse
        local_orig = origin.transform(inv_tr)
        local_dir  = dir.transform(inv_tr)
        next if local_dir.y.abs < 1e-6

        TuAoThamSo.lay_danh_sach_vung_khoang(tu).each do |r|
          t = (r[:y1] - local_orig.y) / local_dir.y
          next if t <= 0
          hit_pt = local_orig.offset(local_dir, t)
          if hit_pt.x >= r[:x1] && hit_pt.x <= r[:x2] && hit_pt.z >= r[:z1] && hit_pt.z <= r[:z2]
            world_hit = hit_pt.transform(tr)
            dist = origin.distance(world_hit)
            if dist < best_dist
              best_dist = dist
              best_reg = r.merge({ :tu_group => tu })
            end
          end
        end
      end

      best_reg
    end
  end

def self.tinh_vi_tri_chia_o(tong_kich_thuoc, day_ngan, bieu_thuc, dao_chieu = false, align_mode = 'duoi')
  raw = bieu_thuc.to_s.strip
  return Array.new if raw.empty? || tong_kich_thuoc <= 0

  tokens = raw.split(',').map(&:strip).reject(&:empty?)
  return Array.new if tokens.empty?

  fixed_sizes = Array.new
  div_count = 0

  tokens.each do |tk|
    if tk.start_with?('/')
      n = tk[1..-1].to_i
      div_count = n if n > 0
    else
      val = tk.gsub(',', '.').to_f.mm
      fixed_sizes << val if val > 0
    end
  end

  # Độ dời chỉ tác động vào điểm dời (các mốc kích thước cố định)
  anchor_shift = case align_mode.to_s
                 when 'giua' then -(day_ngan / 2.0)
                 when 'tren' then -day_ngan
                 else 0.mm
                 end

  vi_tri = Array.new
  pos = 0.mm

  if div_count > 0
    fixed_sizes.each do |sz|
      plate_pos = pos + sz + anchor_shift
      if plate_pos > 0 && (plate_pos + day_ngan) < tong_kich_thuoc
        vi_tri << plate_pos
        pos = plate_pos + day_ngan
      end
    end

    so_vach_chia_deu = div_count - 1
    phan_con_lai = tong_kich_thuoc - pos - (so_vach_chia_deu * day_ngan)
    moi_o_chia = phan_con_lai / div_count.to_f

    if moi_o_chia > 0
      so_vach_chia_deu.times do
        pos += moi_o_chia
        vi_tri << pos if pos > 0 && (pos + day_ngan) < tong_kich_thuoc
        pos += day_ngan
      end
    end
  else
    fixed_sizes.each do |sz|
      plate_pos = pos + sz + anchor_shift
      break if (plate_pos + day_ngan) >= tong_kich_thuoc
      vi_tri << plate_pos if plate_pos > 0
      pos = plate_pos + day_ngan
    end
  end

  if dao_chieu
    vi_tri = vi_tri.map { |p| tong_kich_thuoc - p - day_ngan }.reverse
  end

  vi_tri
end

  def self.tinh_vi_tri_vach_dung(dai_lot_long, day_hoi_trai, day_van, bieu_thuc, uu_tien_phai, co_canh, so_canh, x_bat_dau_canh, rong_moi_canh, khe_canh, align_mode = 'duoi')
    raw = bieu_thuc.to_s.strip
    return Array.new if raw.empty?

    if co_canh && so_canh > 1 && raw.start_with?('/') && !raw.include?(',')
      div_count = raw[1..-1].to_i
      if div_count == so_canh
        vi_tri = Array.new
        (so_canh - 1).times do |i|
          tam_khe_canh = x_bat_dau_canh + (i + 1) * rong_moi_canh + i * khe_canh + (khe_canh / 2.0)
          x_vach_lot = (tam_khe_canh - (day_van / 2.0)) - day_hoi_trai
          vi_tri << x_vach_lot if x_vach_lot > 0 && (x_vach_lot + day_van) < dai_lot_long
        end
        return vi_tri
      end
    end

    self.tinh_vi_tri_chia_o(dai_lot_long, day_van, raw, uu_tien_phai, align_mode)
  end

  def self.cap_nhat_tu(group, params)
    require 'json'

    dai            = params['dai'].to_f.mm
    cao            = params['cao'].to_f.mm
    rong           = params['rong'].to_f.mm
    day_van        = params['day_van'].to_f.mm
    co_canh        = (params['co_canh'] == true || params['co_canh'].to_s == 'true')
    an_canh        = (params['an_canh'] == true || params['an_canh'].to_s == 'true')
    kieu_canh      = params['kieu_canh'].to_s.empty? ? 'trum' : params['kieu_canh'].to_s
    lui_canh_lot   = params['lui_canh_lot'].to_f.mm
    so_canh        = [params['so_canh'].to_i, 1].max
    cach_trai      = params['cach_trai'].to_f.mm
    cach_phai      = params['cach_phai'].to_f.mm
    cach_tren      = params['cach_tren'].to_f.mm
    cach_duoi      = params['cach_duoi'].to_f.mm
    khe_canh       = params['khe_canh'].to_f.mm
    kieu_hau       = params['kieu_hau'].to_s.empty? ? 'cai_hong' : params['kieu_hau'].to_s
    day_hau        = params['day_hau'].to_f.mm
    lui_hau        = params['lui_hau'].to_f.mm
    am_ranh_hau    = params['am_ranh_hau'].to_f.mm
    hong_trai_trum = params['hong_trai_trum'].nil? ? true : (params['hong_trai_trum'] == true || params['hong_trai_trum'].to_s == 'true')
    hong_phai_trum = params['hong_phai_trum'].nil? ? true : (params['hong_phai_trum'] == true || params['hong_phai_trum'].to_s == 'true')
    kieu_chan      = params['kieu_chan'].to_s.empty? ? 'khung_go' : params['kieu_chan'].to_s
    kieu_chan      = 'chan_nhua' if kieu_chan == 'hoi_tren_day'
    cao_chan       = params['cao_chan'].to_f.mm
    lui_chan_truoc = params['lui_chan_truoc'].to_f.mm
    lui_chan_sau   = params['lui_chan_sau'].to_f.mm
    kieu_noc       = params['kieu_noc'].to_s.empty? ? 'ha_noc' : params['kieu_noc'].to_s
    ho_noc         = params['ho_noc'].to_f.mm
    lui_noc        = params['lui_noc'].to_f.mm
    ban_chan_noc   = params['ban_chan_noc'].to_f.mm

    custom_parts  = JSON.parse(group.get_attribute('TuAoConfig', 'custom_parts', '{}')) rescue {}
    chia_map      = JSON.parse(group.get_attribute('TuAoConfig', 'chia_map', '{}')) rescue {}
    deleted_parts = JSON.parse(group.get_attribute('TuAoConfig', 'deleted_parts', '')) rescue Array.new

    params.each do |k, v|
      next if ['custom_parts', 'chia_khoang', 'chia_map', 'deleted_parts', 'manual_trims'].include?(k)
      if ['kieu_canh', 'kieu_hau', 'kieu_chan', 'kieu_noc'].include?(k)
        group.set_attribute('TuAoConfig', k, v.to_s)
      elsif ['co_canh', 'an_canh', 'hong_trai_trum', 'hong_phai_trum'].include?(k)
        group.set_attribute('TuAoConfig', k, (v == true || v.to_s == 'true'))
      else
        group.set_attribute('TuAoConfig', k, v.to_f)
      end
    end
    group.name = "Thung_Tu_Ao_#{params['dai'].to_i}x#{params['cao'].to_i}x#{params['rong'].to_i}"

    ents = group.entities
    manual_trims = JSON.parse(group.get_attribute('TuAoConfig', 'manual_trims', '{}')) rescue {}

    old_dai  = group.get_attribute('TuAoConfig', 'last_dai').to_f
    old_cao  = group.get_attribute('TuAoConfig', 'last_cao').to_f
    old_rong = group.get_attribute('TuAoConfig', 'last_rong').to_f
    if old_dai > 0 && old_cao > 0 && old_rong > 0
      ents.grep(Sketchup::Group).each do |g|
        next unless g.valid? && g.attribute_dictionary('TamConfig')
        orig_bb = g.get_attribute('TamConfig', 'orig_bb')
        next unless orig_bb.is_a?(Array) && orig_bb.length == 6
        cur_bb = g.bounds
        if (cur_bb.min.x - orig_bb[0]).abs > 0.5.mm || (cur_bb.max.x - orig_bb[1]).abs > 0.5.mm ||
           (cur_bb.min.y - orig_bb[2]).abs > 0.5.mm || (cur_bb.max.y - orig_bb[3]).abs > 0.5.mm ||
           (cur_bb.min.z - orig_bb[4]).abs > 0.5.mm || (cur_bb.max.z - orig_bb[5]).abs > 0.5.mm
          manual_trims[g.name] = [
            (cur_bb.min.x - orig_bb[0]).to_f, (cur_bb.max.x - orig_bb[1]).to_f,
            (cur_bb.min.y - orig_bb[2]).to_f, (cur_bb.max.y - orig_bb[3]).to_f,
            (cur_bb.min.z - orig_bb[4]).to_f, (cur_bb.max.z - orig_bb[5]).to_f
          ]
        end
      end
      group.set_attribute('TuAoConfig', 'manual_trims', manual_trims.to_json)
    end
    group.set_attribute('TuAoConfig', 'last_dai', dai.to_f)
    group.set_attribute('TuAoConfig', 'last_cao', cao.to_f)
    group.set_attribute('TuAoConfig', 'last_rong', rong.to_f)

    ents.clear!

    tao_tam_van = lambda do |ten, x, y, z, dx, dy, dz, huong_day = :x_pos, an_tam = false, base_override = nil|
      base_key = base_override || ten
      return if deleted_parts.include?(base_key) || deleted_parts.include?(ten)

      default_d = (huong_day == :x_pos || huong_day == :x_neg) ? dx : ((huong_day == :y_pos || huong_day == :y_neg) ? dy : dz)
      cfg = custom_parts[base_key]

      if cfg
        so_lop = [cfg['lop'].to_i, 1].max
        if so_lop > 1
          lop_days = (cfg['lop_days'].is_a?(Array) && cfg['lop_days'].length == so_lop) ? cfg['lop_days'].map { |v| v.to_f.mm } : Array.new(so_lop, default_d)
        else
          day_tuy_chinh = cfg['day'].to_f.mm
          return if day_tuy_chinh <= 0
          lop_days = [day_tuy_chinh]
        end

        offset = 0.mm
        lop_days.each_with_index do |d_lop, idx|
          next if d_lop <= 0
          ten_lop = so_lop > 1 ? "#{ten}_Lop_#{idx + 1}" : ten
          cx, cy, cz, cdx, cdy, cdz = x, y, z, dx, dy, dz

          case huong_day
          when :x_pos then cx = x + offset; cdx = d_lop
          when :x_neg then cx = (x + dx) - offset - d_lop; cdx = d_lop
          when :y_pos then cy = y + offset; cdy = d_lop
          when :y_neg then cy = (y + dy) - offset - d_lop; cdy = d_lop
          when :z_pos then cz = z + offset; cdz = d_lop
          when :z_neg then cz = (z + dz) - offset - d_lop; cdz = d_lop
          end

          next if cdx <= 0.1.mm || cdy <= 0.1.mm || cdz <= 0.1.mm
          grp = ents.add_group
          grp.name = ten_lop
          grp.visible = !an_tam
          grp.set_attribute('TamConfig', 'base_name', base_key)
          grp.set_attribute('TamConfig', 'default_day', default_d.to_mm.round(1))
          pts = [[cx, cy, cz], [cx + cdx, cy, cz], [cx + cdx, cy + cdy, cz], [cx, cy + cdy, cz]]
          face = grp.entities.add_face(pts)
          if face && face.valid?
            face.reverse! if face.normal.z < 0
            face.pushpull(cdz)
          else
            grp.erase!
          end
          offset += d_lop
        end
      else
        if manual_trims[ten].is_a?(Array) && manual_trims[ten].length == 6
          dt = manual_trims[ten]
          x += dt[0]; dx += (dt[1] - dt[0])
          y += dt[2]; dy += (dt[3] - dt[2])
          z += dt[4]; dz += (dt[5] - dt[4])
        end
        return if dx <= 0.1.mm || dy <= 0.1.mm || dz <= 0.1.mm
        grp = ents.add_group
        grp.name = ten
        grp.visible = !an_tam
        grp.set_attribute('TamConfig', 'base_name', base_key)
        grp.set_attribute('TamConfig', 'default_day', default_d.to_mm.round(1))
        pts = [[x, y, z], [x + dx, y, z], [x + dx, y + dy, z], [x, y + dy, z]]
        face = grp.entities.add_face(pts)
        if face && face.valid?
          face.reverse! if face.normal.z < 0
          face.pushpull(dz)
          bb_new = grp.bounds
          grp.set_attribute('TamConfig', 'orig_bb', [bb_new.min.x.to_f, bb_new.max.x.to_f, bb_new.min.y.to_f, bb_new.max.y.to_f, bb_new.min.z.to_f, bb_new.max.z.to_f])
        else
          grp.erase!
        end
      end
    end

    tinh_day_thuc = lambda do |ten, mac_dinh|
      return 0.mm if deleted_parts.include?(ten)
      cfg = custom_parts[ten]
      return mac_dinh unless cfg
      so_lop = [cfg['lop'].to_i, 1].max
      if so_lop > 1
        (cfg['lop_days'].is_a?(Array) && cfg['lop_days'].length == so_lop) ? cfg['lop_days'].sum { |v| v.to_f }.mm : (mac_dinh * so_lop)
      else
        cfg['day'].to_f.mm
      end
    end

    day_hoi_trai = tinh_day_thuc.call('Hoi_Trai', day_van)
    day_hoi_phai = tinh_day_thuc.call('Hoi_Phai', day_van)
    day_day_tu   = tinh_day_thuc.call('Day_Tu', day_van)
    day_noc_tu   = tinh_day_thuc.call('Noc_Tu', day_van)
    day_hau_thuc = tinh_day_thuc.call('Hau_Tu', day_hau)

    dai_lot_long = dai - day_hoi_trai - day_hoi_phai
    thut_thung   = (kieu_canh == 'lot') ? lui_canh_lot : 0.mm
    z_day        = (kieu_chan != 'khong' && cao_chan > 0) ? cao_chan : 0.mm

    la_noc_trum  = (kieu_noc == 'noc_trum')
    ho_noc_thuc  = (kieu_noc == 'ha_noc') ? ho_noc : 0.mm
    z_noc        = cao - ho_noc_thuc - day_noc_tu

    la_cai_hong  = (kieu_hau == 'cai_hong')
    y_sau_day    = la_cai_hong ? (rong - day_hau_thuc - lui_hau) : rong
    y_sau_noc    = (la_noc_trum || la_cai_hong) ? (rong - day_hau_thuc - lui_hau) : rong

    if kieu_canh == 'trum'
      x_bat_dau_canh = cach_trai
      tong_rong_canh = dai - cach_trai - cach_phai
    else
      x_bat_dau_canh = day_hoi_trai + cach_trai
      tong_rong_canh = dai_lot_long - cach_trai - cach_phai
    end
    rong_moi_canh = (tong_rong_canh - (khe_canh * (so_canh - 1))) / so_canh.to_f

    z_hoi_trai   = hong_trai_trum ? 0.mm : (z_day + day_day_tu)
    z_dinh_trai  = (hong_trai_trum && !la_noc_trum) ? cao : z_noc
    sau_hoi_trai = (la_cai_hong && !hong_trai_trum) ? y_sau_day : rong
    tao_tam_van.call('Hoi_Trai', 0.mm, 0.mm, z_hoi_trai, day_van, sau_hoi_trai, z_dinh_trai - z_hoi_trai, :x_pos)

    z_hoi_phai   = hong_phai_trum ? 0.mm : (z_day + day_day_tu)
    z_dinh_phai  = (hong_phai_trum && !la_noc_trum) ? cao : z_noc
    sau_hoi_phai = (la_cai_hong && !hong_phai_trum) ? y_sau_day : rong
    tao_tam_van.call('Hoi_Phai', dai - day_van, 0.mm, z_hoi_phai, day_van, sau_hoi_phai, z_dinh_phai - z_hoi_phai, :x_neg)

    x_bat_dau_ngang  = hong_trai_trum ? day_hoi_trai : 0.mm
    x_ket_thuc_ngang = hong_phai_trum ? (dai - day_hoi_phai) : dai
    dai_tam_ngang    = x_ket_thuc_ngang - x_bat_dau_ngang

    if kieu_chan != 'khong' && cao_chan > 0
y_chan_truoc = thut_thung + lui_chan_truoc
tao_tam_van.call('Chan_Truoc', x_bat_dau_ngang, y_chan_truoc, 0.mm, dai_tam_ngang, day_van, cao_chan, :y_pos)
if kieu_chan == 'khung_go'
y_chan_sau = rong - lui_chan_sau - day_van
tao_tam_van.call('Chan_Sau', day_hoi_trai, y_chan_sau, 0.mm, dai_lot_long, day_van, cao_chan, :y_neg)
y_bat_dau_giang = y_chan_truoc + day_van
sau_thanh_ngang_chan = y_chan_sau - y_bat_dau_giang
if sau_thanh_ngang_chan > 0
tao_tam_van.call('Chan_Trai', day_hoi_trai, y_bat_dau_giang, 0.mm, day_van, sau_thanh_ngang_chan, cao_chan, :x_pos)
tao_tam_van.call('Chan_Phai', dai - day_hoi_phai - day_van, y_bat_dau_giang, 0.mm, day_van, sau_thanh_ngang_chan, cao_chan, :x_neg)
if co_canh && so_canh > 2
(so_canh - 1).times do |i|
tam_khe_canh = x_bat_dau_canh + (i + 1) * rong_moi_canh + i * khe_canh + (khe_canh / 2.0)
x_giang = tam_khe_canh - (day_van / 2.0)
tao_tam_van.call("Giang_Chan_#{i + 1}", x_giang, y_bat_dau_giang, 0.mm, day_van, sau_thanh_ngang_chan, cao_chan, :x_pos)
end
else
tao_tam_van.call('Giang_Chan_Giua', (dai - day_van) / 2.0, y_bat_dau_giang, 0.mm, day_van, sau_thanh_ngang_chan, cao_chan, :x_pos)
end
end
end
end
    sau_day = y_sau_day - thut_thung
    tao_tam_van.call('Day_Tu', x_bat_dau_ngang, thut_thung, z_day, dai_tam_ngang, sau_day, day_van, :z_pos)

    x_noc   = la_noc_trum ? 0.mm : x_bat_dau_ngang
    dai_noc = la_noc_trum ? dai : dai_tam_ngang
    sau_noc = y_sau_noc - thut_thung
    tao_tam_van.call('Noc_Tu', x_noc, thut_thung, cao - ho_noc_thuc - day_van, dai_noc, sau_noc, day_van, :z_neg)

    if kieu_noc == 'ha_noc' && ho_noc > 0
      y_xa_noc = thut_thung + lui_noc
      tao_tam_van.call('Xa_Noc_Truoc', x_bat_dau_ngang, y_xa_noc, cao - ho_noc, dai_tam_ngang, day_van, ho_noc, :y_pos)
      if ban_chan_noc > 0
        z_chan_noc = z_noc + day_noc_tu
        y_chan_noc = y_xa_noc + day_van
        tao_tam_van.call('Thanh_Chan_Noc', x_bat_dau_ngang, y_chan_noc, z_chan_noc, dai_tam_ngang, ban_chan_noc, day_van, :z_pos)
      end
    end

    if kieu_hau != 'khong_hau' && day_hau_thuc > 0
      y_hau = rong - lui_hau - day_hau_thuc
      if kieu_hau == 'cai_hong'
        x_hau      = hong_trai_trum ? (day_hoi_trai - am_ranh_hau) : 0.mm
        x_hau_phai = hong_phai_trum ? (dai - day_hoi_phai + am_ranh_hau) : dai
        dai_hau    = x_hau_phai - x_hau
        z_hau_duoi = z_day
        z_hau_tren = z_noc + day_noc_tu
      elsif kieu_hau == 'cai_het_khung'
        x_hau      = day_hoi_trai - am_ranh_hau
        dai_hau    = dai_lot_long + (2 * am_ranh_hau)
        z_hau_duoi = (z_day + day_day_tu) - am_ranh_hau
        z_hau_tren = z_noc + am_ranh_hau
      elsif kieu_hau == 'lot_long'
        x_hau      = day_hoi_trai
        dai_hau    = dai_lot_long
        z_hau_duoi = z_day + day_day_tu
        z_hau_tren = z_noc
      end
      cao_hau = z_hau_tren - z_hau_duoi
      tao_tam_van.call('Hau_Tu', x_hau, y_hau, z_hau_duoi, dai_hau, day_hau, cao_hau, :y_neg)
    end

    z_lot_duoi   = z_day + day_day_tu
    y_sau_ngan   = (kieu_hau != 'khong_hau' && day_hau_thuc > 0) ? (rong - lui_hau - day_hau_thuc) : rong

    vach_counter = 0
    dot_counter  = 0
    leaf_regions = Array.new

    xu_ly_vung = lambda do |path, rx1, rx2, ry1, ry2, rz1, rz2|
      cfg = chia_map[path]
      vach_expr    = cfg ? cfg['vach_expr'].to_s.strip : ''
      vach_uu_tien = cfg ? (cfg['vach_uu_tien'] || 'trai') : 'trai'
      vach_lui     = cfg ? cfg['vach_lui'].to_f.mm : 0.mm

      dot_expr     = cfg ? cfg['dot_expr'].to_s.strip : ''
      dot_uu_tien  = cfg ? (cfg['dot_uu_tien'] || 'duoi') : 'duoi'
      dot_lui      = cfg ? cfg['dot_lui'].to_f.mm : 0.mm
      align_mode   = cfg ? (cfg['align_mode'] || 'duoi') : 'duoi'

      rong_vung = rx2 - rx1
      cao_vung  = rz2 - rz1
      sau_vung  = ry2 - ry1

      vi_tri_v = (!vach_expr.empty? && rong_vung > day_van && sau_vung > vach_lui) ?
        self.tinh_vi_tri_vach_dung(rong_vung, rx1, day_van, vach_expr, (vach_uu_tien == 'phai'), (co_canh && path == 'root'), so_canh, x_bat_dau_canh, rong_moi_canh, khe_canh, align_mode) : Array.new

      vi_tri_d = (!dot_expr.empty? && cao_vung > day_van && sau_vung > dot_lui) ?
        self.tinh_vi_tri_chia_o(cao_vung, day_van, dot_expr, (dot_uu_tien == 'tren'), align_mode) : Array.new

      if !vi_tri_v.empty? && !vi_tri_d.empty?
        x_bounds = [rx1]
        v_names  = Array.new
        vi_tri_v.each do |dx_pos|
          vach_counter += 1
          vn = "Vach_Dung_#{vach_counter}"
          v_names << vn
          day_v_thuc = tinh_day_thuc.call(vn, day_van)
          v_x = rx1 + dx_pos - ((day_v_thuc - day_van) / 2.0)
          tao_tam_van.call(vn, v_x, ry1 + vach_lui, rz1, day_v_thuc, sau_vung - vach_lui, cao_vung, :x_pos)
          x_bounds << v_x
          x_bounds << (v_x + day_v_thuc)
        end
        x_bounds << rx2

        z_bounds = [rz1]
        d_names  = Array.new
        vi_tri_d.each do |dz_pos|
          dot_counter += 1
          dn = "Dot_Ngang_#{dot_counter}"
          d_names << dn
          day_d_thuc = tinh_day_thuc.call(dn, day_van)
          d_z = rz1 + dz_pos - ((day_d_thuc - day_van) / 2.0)
          tao_tam_van.call(dn, rx1, ry1 + dot_lui, d_z, rong_vung, sau_vung - dot_lui, day_d_thuc, :z_pos)
          z_bounds << d_z
          z_bounds << (d_z + day_d_thuc)
        end
        z_bounds << rz2

        (v_names.length + 1).times do |vi|
          (d_names.length + 1).times do |di|
            sub_path = "#{path}.v#{vi + 1}.d#{di + 1}"
            xu_ly_vung.call(sub_path, x_bounds[vi * 2], x_bounds[vi * 2 + 1], ry1, ry2, z_bounds[di * 2], z_bounds[di * 2 + 1])
          end
        end
      elsif !vi_tri_v.empty?
        cur_x = rx1
        vi_tri_v.each_with_index do |dx_pos, idx|
          vach_counter += 1
          vn = "Vach_Dung_#{vach_counter}"
          day_v_thuc = tinh_day_thuc.call(vn, day_van)
          v_x = rx1 + dx_pos - ((day_v_thuc - day_van) / 2.0)
          tao_tam_van.call(vn, v_x, ry1 + vach_lui, rz1, day_v_thuc, sau_vung - vach_lui, cao_vung, :x_pos)
          xu_ly_vung.call("#{path}.v#{idx + 1}", cur_x, v_x, ry1, ry2, rz1, rz2)
          cur_x = v_x + day_v_thuc
        end
        xu_ly_vung.call("#{path}.v#{vi_tri_v.length + 1}", cur_x, rx2, ry1, ry2, rz1, rz2)
      elsif !vi_tri_d.empty?
        cur_z = rz1
        vi_tri_d.each_with_index do |dz_pos, idx|
          dot_counter += 1
          dn = "Dot_Ngang_#{dot_counter}"
          day_d_thuc = tinh_day_thuc.call(dn, day_van)
          d_z = rz1 + dz_pos - ((day_d_thuc - day_van) / 2.0)
          tao_tam_van.call(dn, rx1, ry1 + dot_lui, d_z, rong_vung, sau_vung - dot_lui, day_d_thuc, :z_pos)
          xu_ly_vung.call("#{path}.d#{idx + 1}", rx1, rx2, ry1, ry2, cur_z, d_z)
          cur_z = d_z + day_d_thuc
        end
        xu_ly_vung.call("#{path}.d#{vi_tri_d.length + 1}", rx1, rx2, ry1, ry2, cur_z, rz2)
      else
        leaf_regions << { :path => path, :x1 => rx1, :x2 => rx2, :y1 => ry1, :y2 => ry2, :z1 => rz1, :z2 => rz2 }
      end
    end

    xu_ly_vung.call('root', day_hoi_trai, dai - day_hoi_phai, thut_thung, y_sau_ngan, z_lot_duoi, z_noc)
    leaf_regions << { :path => 'root', :x1 => day_hoi_trai, :x2 => dai - day_hoi_phai, :y1 => thut_thung, :y2 => y_sau_ngan, :z1 => z_lot_duoi, :z2 => z_noc } if leaf_regions.empty?

    group.set_attribute('TuAoConfig', 'leaf_regions_cache', leaf_regions.map { |r|
      { 'path' => r[:path], 'x1' => r[:x1].to_f, 'x2' => r[:x2].to_f, 'y1' => r[:y1].to_f, 'y2' => r[:y2].to_f, 'z1' => r[:z1].to_f, 'z2' => r[:z2].to_f }
    }.to_json)

    if co_canh
      y_canh = (kieu_canh == 'trum') ? (-day_van - 1.mm) : [thut_thung - day_van - 1.mm, 1.mm].max
      z_canh_duoi = z_day + cach_duoi
      z_canh_tren = (kieu_noc == 'ha_noc') ? (z_noc + day_noc_tu - cach_tren) : (cao - cach_tren)
      cao_canh = z_canh_tren - z_canh_duoi

      so_canh.times do |i|
        x_c = x_bat_dau_canh + i * (rong_moi_canh + khe_canh)
        tao_tam_van.call("Canh_Tu_#{i + 1}", x_c, y_canh, z_canh_duoi, rong_moi_canh, day_van, cao_canh, :y_neg, an_canh)
      end
    end
  end

  def self.dat_tu_hien_tai(tu_group)
    @current_tu_group = tu_group
  end

  def self.lay_danh_sach_vung_khoang(tu_group)
    require 'json'
    return Array.new unless tu_group && tu_group.valid?

    chia_map = JSON.parse(tu_group.get_attribute('TuAoConfig', 'chia_map', '{}')) rescue {}
    if chia_map.empty?
      params = self.lay_thong_so_tu_group(tu_group)
      if params
        dai     = params['dai'].to_f.mm
        cao     = params['cao'].to_f.mm
        rong    = params['rong'].to_f.mm
        day_van = params['day_van'].to_f.mm
        thut    = (params['kieu_canh'] == 'lot') ? params['lui_canh_lot'].to_f.mm : 0.mm
        z_day   = (params['kieu_chan'] != 'khong' && params['cao_chan'].to_f > 0) ? params['cao_chan'].to_f.mm : 0.mm
        ho_noc  = (params['kieu_noc'] == 'ha_noc') ? params['ho_noc'].to_f.mm : 0.mm
        z_noc   = cao - ho_noc - day_van
        y_sau   = (params['kieu_hau'] != 'khong_hau' && params['day_hau'].to_f > 0) ? (rong - params['lui_hau'].to_f.mm - params['day_hau'].to_f.mm) : rong
        return [{
          :path => 'root',
          :x1   => day_van, :x2 => dai - day_van,
          :y1   => thut,    :y2 => y_sau,
          :z1   => z_day + day_van, :z2 => z_noc
        }]
      end
    end

    raw = tu_group.get_attribute('TuAoConfig', 'leaf_regions_cache', '')
    arr = JSON.parse(raw) rescue Array.new
    arr.map do |r|
      {
        :path => r['path'].to_s,
        :x1   => r['x1'].to_f, :x2 => r['x2'].to_f,
        :y1   => r['y1'].to_f, :y2 => r['y2'].to_f,
        :z1   => r['z1'].to_f, :z2 => r['z2'].to_f
      }
    end
  end

  def self.mo_bang_chia_cho_vung(tu_group, reg)
    require 'json'
    return unless @dialog && @dialog.visible?
    chia_map = JSON.parse(tu_group.get_attribute('TuAoConfig', 'chia_map', '{}')) rescue {}
    cfg = chia_map[reg[:path]] || {}
    payload = {
      'path'         => reg[:path],
      'vach_uu_tien' => cfg['vach_uu_tien'] || 'trai',
      'vach_lui'     => cfg['vach_lui'] || 0,
      'dot_uu_tien'  => cfg['dot_uu_tien'] || 'duoi',
      'dot_lui'      => cfg['dot_lui'] || 0
    }
    @dialog.execute_script("hienBangChiaChoVung(#{payload.to_json})")
  end

  def self.chot_ap_dung_preview(tu_group, path, data)
    return if @is_updating
    require 'json'
    return unless tu_group && tu_group.valid?

    target_path = path.to_s.empty? ? 'root' : path.to_s
    v_str = data['vach_expr'].to_s.strip
    d_str = data['dot_expr'].to_s.strip
    return if v_str.empty? && d_str.empty?

    model = Sketchup.active_model
    @is_updating = true
    begin
      model.start_operation('T2MS-Mod: Áp dụng chia khoang', true)
      chia_map = JSON.parse(tu_group.get_attribute('TuAoConfig', 'chia_map', '{}')) rescue {}
      chia_map[target_path] = {
        'vach_expr'    => v_str,
        'vach_uu_tien' => data['vach_uu_tien'] || 'trai',
        'vach_lui'     => data['vach_lui'].to_f,
        'dot_expr'     => d_str,
        'dot_uu_tien'  => data['dot_uu_tien'] || 'duoi',
        'dot_lui'      => data['dot_lui'].to_f,
        'align_mode'   => data['align_mode'] || 'duoi'
      }
      tu_group.set_attribute('TuAoConfig', 'chia_map', chia_map.to_json)

      params = self.lay_thong_so_tu_group(tu_group)
      self.cap_nhat_tu(tu_group, params) if params
      model.commit_operation
    rescue => e
      model.abort_operation
      puts "Loi Ap Dung Chia Khoang: #{e.message}"
    ensure
      @is_updating = false
    end
  end

  def self.xoa_chia_vung(tu_group, path)
    return if @is_updating
    require 'json'
    return unless tu_group && tu_group.valid?

    target_path = path.to_s.empty? ? 'root' : path.to_s
    model = Sketchup.active_model
    @is_updating = true
    begin
      model.start_operation('T2MS-Mod: Xóa chia khoang', true)
      chia_map = JSON.parse(tu_group.get_attribute('TuAoConfig', 'chia_map', '{}')) rescue {}

      while !chia_map.key?(target_path) && target_path.include?('.')
        target_path = target_path.sub(/\.[^.]+$/, '')
      end

      chia_map.delete(target_path)
      chia_map.keys.each { |k| chia_map.delete(k) if k.start_with?("#{target_path}.") }
      tu_group.set_attribute('TuAoConfig', 'chia_map', chia_map.to_json)

      params = self.lay_thong_so_tu_group(tu_group)
      self.cap_nhat_tu(tu_group, params) if params
      model.commit_operation
    rescue => e
      model.abort_operation
      puts "Loi Xoa Chia Vung: #{e.message}"
    ensure
      @is_updating = false
    end
  end

  def self.xoa_tam_dang_chon(tu_group, base_name)
    return if @is_updating
    require 'json'
    return unless tu_group && tu_group.valid? && !base_name.to_s.empty?

    model = Sketchup.active_model
    @is_updating = true
    begin
      model.start_operation("T2MS-Mod: Xóa tấm #{base_name}", true)
      deleted_parts = JSON.parse(tu_group.get_attribute('TuAoConfig', 'deleted_parts', '')) rescue Array.new
      deleted_parts << base_name unless deleted_parts.include?(base_name)
      tu_group.set_attribute('TuAoConfig', 'deleted_parts', deleted_parts.to_json)

      params = self.lay_thong_so_tu_group(tu_group)
      self.cap_nhat_tu(tu_group, params) if params

      model.selection.clear
      model.selection.add(tu_group)
      @dialog.execute_script("anBangChiTietTamSauKhiXoa()") if @dialog && @dialog.visible?
      model.commit_operation
    rescue => e
      model.abort_operation
      puts "Loi Xoa Tam: #{e.message}"
    ensure
      @is_updating = false
    end
  end

  def self.khoi_phuc_tat_ca_tam_da_xoa(tu_group)
    return if @is_updating
    return unless tu_group && tu_group.valid?

    model = Sketchup.active_model
    @is_updating = true
    begin
      model.start_operation("T2MS-Mod: Khôi phục tấm đã xóa", true)
      tu_group.set_attribute('TuAoConfig', 'deleted_parts', '')
      tu_group.set_attribute('TuAoConfig', 'manual_trims', '{}')
      params = self.lay_thong_so_tu_group(tu_group)
      self.cap_nhat_tu(tu_group, params) if params
      model.commit_operation
    rescue => e
      model.abort_operation
    ensure
      @is_updating = false
    end
  end
  def self.lay_thong_so_tu_group(target)
    return nil unless target && target.valid? && target.attribute_dictionary('TuAoConfig')

    dict = target.attribute_dictionary('TuAoConfig')
    kc = dict['kieu_chan'] || 'khung_go'
    kc = 'chan_nhua' if kc == 'hoi_tren_day'

    {
      'dai' => dict['dai'], 'cao' => dict['cao'], 'rong' => dict['rong'],
      'day_van' => dict['day_van'],
      'co_canh' => dict['co_canh'] == true,
      'an_canh' => dict['an_canh'] == true,
      'kieu_canh' => dict['kieu_canh'] || 'trum',
      'lui_canh_lot' => dict['lui_canh_lot'].nil? ? 20 : dict['lui_canh_lot'],
      'so_canh' => dict['so_canh'].nil? ? 2 : dict['so_canh'].to_i,
      'cach_trai' => dict['cach_trai'].nil? ? 2 : dict['cach_trai'],
      'cach_phai' => dict['cach_phai'].nil? ? 2 : dict['cach_phai'],
      'cach_tren' => dict['cach_tren'].nil? ? 2 : dict['cach_tren'],
      'cach_duoi' => dict['cach_duoi'].nil? ? 2 : dict['cach_duoi'],
      'khe_canh' => dict['khe_canh'].nil? ? 3 : dict['khe_canh'],
      'kieu_hau' => dict['kieu_hau'] || 'cai_hong',
      'day_hau' => dict['day_hau'].nil? ? 9 : dict['day_hau'],
      'lui_hau' => dict['lui_hau'].nil? ? 10 : dict['lui_hau'],
      'am_ranh_hau' => dict['am_ranh_hau'].nil? ? 8 : dict['am_ranh_hau'],
      'hong_trai_trum' => dict['hong_trai_trum'].nil? ? true : dict['hong_trai_trum'],
      'hong_phai_trum' => dict['hong_phai_trum'].nil? ? true : dict['hong_phai_trum'],
      'kieu_chan' => kc,
      'cao_chan' => dict['cao_chan'].nil? ? 100 : dict['cao_chan'],
      'lui_chan_truoc' => dict['lui_chan_truoc'].nil? ? 2 : dict['lui_chan_truoc'],
      'lui_chan_sau' => dict['lui_chan_sau'].nil? ? 25 : dict['lui_chan_sau'],
      'kieu_noc' => dict['kieu_noc'] || 'ha_noc',
      'ho_noc' => dict['ho_noc'].nil? ? 50 : dict['ho_noc'],
      'lui_noc' => dict['lui_noc'].nil? ? 2 : dict['lui_noc'],
      'ban_chan_noc' => dict['ban_chan_noc'].nil? ? 70 : dict['ban_chan_noc']
    }
  end

  def self.lay_thong_so_tu_selection
    self.lay_thong_so_tu_group(self.tim_tu_dang_chon)
  end

  def self.thong_bao_thoat_chinh_tam
    @dialog.execute_script("thoatCheDoChinhTam()") if @dialog && @dialog.visible?
  end

  def self.thong_bao_thoat_chia_khoang
    @dialog.execute_script("thoatCheDoChiaKhoang()") if @dialog && @dialog.visible?
  end

  def self.lay_chuoi_hien_tai_cua_tam(tu_group, base_name, default_day)
    require 'json'
    default_disp = (default_day.to_i == default_day) ? default_day.to_i : default_day
    custom_parts = JSON.parse(tu_group.get_attribute('TuAoConfig', 'custom_parts', '{}')) rescue {}
    cfg = custom_parts[base_name]
    return default_disp.to_s unless cfg

    so_lop = [cfg['lop'].to_i, 1].max
    if so_lop > 1 && cfg['lop_days'].is_a?(Array)
      cfg['lop_days'].map { |v| (v.to_f.to_i == v.to_f) ? v.to_i : v.to_f }.join('/')
    else
      d = cfg['day'].to_f
      (d.to_i == d) ? d.to_i.to_s : d.to_s
    end
  end

  def self.ap_dung_thong_so_tam_tu_vcb(tu_group, base_name, tong_day, lop, parts)
    return if @is_updating
    require 'json'
    model = Sketchup.active_model
    @is_updating = true
    begin
      model.start_operation('T2MS-Mod: Nhập nhanh từ VCB', true)
      custom_parts = JSON.parse(tu_group.get_attribute('TuAoConfig', 'custom_parts', '{}')) rescue {}
      custom_parts[base_name] = { 'day' => tong_day.to_f, 'lop' => lop.to_i, 'lop_days' => parts }
      tu_group.set_attribute('TuAoConfig', 'custom_parts', custom_parts.to_json)

      params = self.lay_thong_so_tu_group(tu_group)
      self.cap_nhat_tu(tu_group, params) if params

      tam_moi = tu_group.entities.grep(Sketchup::Group).find { |g| g.get_attribute('TamConfig', 'base_name') == base_name }
      if tam_moi && tam_moi.valid?
        model.selection.clear
        model.selection.add(tam_moi)
      end
      model.commit_operation
    rescue => e
      model.abort_operation
      puts "Loi VCB Tam: #{e.message}"
    ensure
      @is_updating = false
    end

    if @dialog && @dialog.visible?
      tam_str = parts.map { |v| (v.to_i == v) ? v.to_i : v }.join('/')
      payload = {
        'base_name'   => base_name,
        'default_day' => tu_group.get_attribute('TuAoConfig', 'day_van', 17.0),
        'day'         => (tong_day.to_i == tong_day) ? tong_day.to_i : tong_day,
        'lop'         => lop,
        'tam_str'     => tam_str
      }
      @dialog.execute_script("hienChiTietTam(#{payload.to_json})")
    end
  end

  def self.hien_bang_chi_tiet_tam(tu_group, tam_group)
    require 'json'
    base_name    = tam_group.get_attribute('TamConfig', 'base_name') || tam_group.name
    default_day  = (tam_group.get_attribute('TamConfig', 'default_day') || tu_group.get_attribute('TuAoConfig', 'day_van', 17.0)).to_f
    default_disp = (default_day.to_i == default_day) ? default_day.to_i : default_day

    custom_parts = JSON.parse(tu_group.get_attribute('TuAoConfig', 'custom_parts', '{}')) rescue {}
    cfg = custom_parts[base_name] || { 'day' => default_disp, 'lop' => 1 }

    day_hien_tai = cfg['day'].to_f
    day_disp     = (day_hien_tai.to_i == day_hien_tai) ? day_hien_tai.to_i : day_hien_tai
    so_lop       = [cfg['lop'].to_i, 1].max

    if so_lop > 1
      tam_str = (cfg['lop_days'].is_a?(Array) && cfg['lop_days'].length == so_lop) ?
        cfg['lop_days'].map { |v| (v.to_f.to_i == v.to_f) ? v.to_i : v.to_f }.join('/') : Array.new(so_lop, default_disp).join('/')
    else
      tam_str = day_disp.to_s
    end

    if @dialog && @dialog.visible?
      payload = { 'base_name' => base_name, 'default_day' => default_disp, 'day' => day_disp, 'lop' => so_lop, 'tam_str' => tam_str }
      @dialog.execute_script("hienChiTietTam(#{payload.to_json})")
    end
    tam_str
  end

  def self.tao_html_giao_dien
    html_phan_than = <<~HTML
      <!DOCTYPE html>
      <html>
      <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; font-size: 11.5px; padding: 8px 10px; background: #f4f4f4; color: #222; margin: 0; }
        .preset-bar { display: flex; gap: 6px; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid #d0d0d0; }
        .preset-btn { flex: 1; height: 48px; background: #ffffff; border: 1.5px solid #cccccc; border-radius: 4px; cursor: pointer; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 2px; transition: all 0.15s; }
        .preset-btn:hover { border-color: #0078d7; background: #eef6fc; }
        .preset-btn.active { border-color: #0078d7; background: #e3f1fc; box-shadow: 0 0 0 1px #0078d7; }
        .preset-btn.empty { background: #eaeaea; border: 1.5px dashed #bcbcbc; cursor: default; color: #888; }
        .preset-btn.ext-btn { background: #fff8e6; border: 1.5px solid #e0a800; color: #856404; }
        .preset-btn.ext-btn.active-tool { background: #ffc107; border-color: #d39e00; color: #000; box-shadow: 0 0 0 1px #d39e00; }
        .preset-btn.div-btn { background: #e8f5e9; border: 1.5px solid #2e7d32; color: #1b5e20; }
        .preset-btn.div-btn.active-tool { background: #4caf50; border-color: #1b5e20; color: #fff; box-shadow: 0 0 0 1px #1b5e20; }
        .preset-btn.div-btn.active-tool span { color: #fff; }
        .preset-btn span { font-size: 9.5px; font-weight: 600; margin-top: 2px; color: #333; }
        .row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px; height: 22px; }
        label { flex: 1; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding-right: 6px; }
        input[type="number"], input[type="text"], select { width: 125px; height: 21px; padding: 1px 5px; border: 1px solid #ccc; border-radius: 3px; font-size: 11.5px; box-sizing: border-box; }
        input[type="number"] { text-align: right; }
        input[type="checkbox"] { width: 14px; height: 14px; cursor: pointer; margin: 0; }
        .chk-group { width: 125px; display: flex; align-items: center; gap: 12px; }
        .chk-item { display: flex; align-items: center; gap: 4px; cursor: pointer; font-weight: 500; font-size: 11.5px; }
        select { text-align-last: left; background: white; cursor: pointer; padding: 0 3px; }
        input:focus, select:focus { border-color: #0078d7; outline: none; }
        .sub-box { background: #e9eff5; border-left: 2.5px solid #0078d7; padding: 4px 6px; margin: 4px 0; border-radius: 0 3px 3px 0; }
        .sub-title { font-size: 10.5px; font-weight: bold; color: #005a9e; margin-bottom: 3px; text-transform: uppercase; }
        hr { border: 0; border-top: 1px solid #dcdcdc; margin: 5px 0; }
        .btn-group { margin-top: 8px; display: flex; gap: 6px; }
        .action-btn { flex: 1; padding: 6px; border: none; border-radius: 3px; cursor: pointer; font-weight: bold; font-size: 11.5px; }
        .btn-create { background: #28a745; color: white; }
        .btn-create:hover { background: #218838; }
        .btn-update { background: #0078d7; color: white; }
        .btn-update:hover { background: #005a9e; }
        .note { font-size: 10px; color: #666; margin-top: 5px; line-height: 1.3; }
        .ext-panel { display: none; margin-bottom: 8px; background: #fffdf9; border: 1.5px solid #d9534f; border-radius: 4px; padding: 7px 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.08); }
        .ext-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; border-bottom: 1px solid #eee; padding-bottom: 4px; }
        .ext-title { font-weight: bold; color: #c9302c; font-size: 11.5px; }
        .ext-close { cursor: pointer; font-weight: bold; color: #888; border: none; background: none; font-size: 13px; padding: 0 2px; }
        .ext-close:hover { color: #c9302c; }
        .ext-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.ext-row label { font-size: 12px; font-weight: bold; color: #c9302c; }
.ext-row input { width: 115px; height: 23px; font-size: 12.5px; font-weight: bold; text-align: center; border: 1.5px solid #c9302c; color: #c9302c; border-radius: 3px; background: #fff; }
.div-panel { display: none; margin-bottom: 8px; background: #f4fbf4; border: 1.5px solid #2e7d32; border-radius: 4px; padding: 7px 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.08); }
.div-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; border-bottom: 1px solid #d8ebd8; padding-bottom: 4px; }
.div-title { font-weight: bold; color: #1b5e20; font-size: 11.5px; }
.div-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.div-row label { font-size: 11.5px; font-weight: bold; color: #1b5e20; }
.div-row input[type="text"], .div-row input[type="number"] { width: 115px; height: 22px; font-size: 11.5px; font-weight: bold; border: 1.5px solid #2e7d32; color: #1b5e20; border-radius: 3px; background: #fff; }
.div-row input[type="text"] { text-align: center; }
.div-chk-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; padding-left: 6px; }
.div-chk-row span { font-size: 11px; color: #2e7d32; font-weight: 600; }
.div-chk-group { width: 115px; display: flex; align-items: center; justify-content: space-between; }
.btn-apply-div { width: 100%; margin-top: 5px; padding: 5px; background: #2e7d32; color: #fff; border: none; border-radius: 3px; font-weight: bold; font-size: 11.5px; cursor: pointer; }
.btn-apply-div:hover { background: #1b5e20; }
      </style>
      </head>
      <body>
        <div class="preset-bar">
          <button type="button" class="preset-btn active" onclick="chonMauTuAo()" title="Nạp thông số Tủ Áo Chuẩn">
            <svg width="22" height="24" viewBox="0 0 24 28" fill="none" stroke="#1e5a96" stroke-width="1.6">
              <rect x="3" y="2" width="18" height="24" fill="#dcebf7"/>
              <line x1="3" y1="5" x2="21" y2="5"/><line x1="3" y1="23" x2="21" y2="23"/><line x1="12" y1="23" x2="12" y2="26"/>
            </svg>
            <span>Tủ Áo</span>
          </button>
          <button type="button" class="preset-btn ext-btn" id="btn_mo_rong" onclick="batTatMoRong()" title="Click chọn tấm bất kỳ để chỉnh độ dày hoặc nhấn Delete để xóa">
            <svg width="22" height="24" viewBox="0 0 24 24" fill="none" stroke="#856404" stroke-width="1.8">
              <path d="M5 3l14 9-6 1.5 3.5 6.5-2.5 1.2-3.5-6.5L6 19V3z" fill="#ffe8a1"/>
            </svg>
            <span>Chỉnh tấm</span>
          </button>
          <button type="button" class="preset-btn div-btn" id="btn_chia_khoang" onclick="batTatChiaKhoang()" title="Rê chuột chọn khoang (xanh lá) -> Click để chọn (vàng) -> Chia khoang">
            <svg width="22" height="24" viewBox="0 0 24 24" fill="none" stroke="#1b5e20" stroke-width="1.7">
              <rect x="3" y="3" width="18" height="18" fill="#c8e6c9"/>
              <line x1="12" y1="3" x2="12" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/>
            </svg>
            <span>Chia khoang</span>
          </button>
          <button type="button" class="preset-btn" style="background:#eef4ff;border-color:#4a7ebb;" onclick="sketchup.moThuVien()" title="Mở Thư viện mẫu tủ T2MS-Mod"><svg width="22" height="24" viewBox="0 0 24 24" fill="none" stroke="#1e5a96" stroke-width="1.7"><path d="M3 6h6l2 2h10v11H3z" fill="#dcebf7"/></svg><span>Thư viện</span></button><button type="button" onclick="sketchup.kiemTraUpdateNet()" title="Kiểm tra & Cập nhật qua Internet (Phiên bản hiện tại: T2MS-1.01)" style="margin-left:5px;padding:4px 8px;background:#10b981;color:#fff;border:none;border-radius:4px;font-size:11px;font-weight:600;cursor:pointer;">🔄 T2MS-1.01</button>
        </div>

        <div class="div-panel" id="div_panel">
          <div class="div-header">
            <span class="div-title" id="div_region_title">Chia Khoang (Vùng đang chọn)</span>
            <button type="button" class="ext-close" onclick="dongBangChiaKhoang()" title="Kết thúc lệnh chia khoang">✕</button>
          </div>
          <input type="hidden" id="div_region_path" value="root">
          <div class="div-row">
            <label>Số đợt dọc:</label>
            <input type="text" id="div_vach_expr" placeholder="VD: /3 hoặc 300,/2" oninput="moPhongChiaKhoang()">
          </div>
          <div class="div-chk-row">
            <span>Ưu tiên đợt dọc:</span>
            <div class="div-chk-group">
              <label class="chk-item" style="color:#1b5e20;"><input type="checkbox" id="div_vach_trai" checked onchange="chonUuTienVach('trai')"> Trái</label>
              <label class="chk-item" style="color:#1b5e20;"><input type="checkbox" id="div_vach_phai" onchange="chonUuTienVach('phai')"> Phải</label>
            </div>
          </div>
          <div class="div-row">
            <label style="font-weight:500;padding-left:6px;">Lùi mặt trước (mm):</label>
            <input type="number" id="div_vach_lui" value="0" min="0" oninput="moPhongChiaKhoang()">
          </div>
          <hr style="border-top:1px dashed #b8d8b8;margin:5px 0;">
          <div class="div-row">
            <label>Số đợt ngang:</label>
            <input type="text" id="div_dot_expr" placeholder="VD: /4 hoặc 400,/2" oninput="moPhongChiaKhoang()">
          </div>
          <div class="div-chk-row">
            <span>Ưu tiên đợt ngang:</span>
            <div class="div-chk-group">
              <label class="chk-item" style="color:#1b5e20;"><input type="checkbox" id="div_dot_tren" onchange="chonUuTienDot('tren')"> Trên</label>
              <label class="chk-item" style="color:#1b5e20;"><input type="checkbox" id="div_dot_duoi" checked onchange="chonUuTienDot('duoi')"> Dưới</label>
            </div>
          </div>
          <div class="div-row">
            <label style="font-weight:500;padding-left:6px;">Lùi mặt trước (mm):</label>
            <input type="number" id="div_dot_lui" value="0" min="0" oninput="moPhongChiaKhoang()">
          </div>
          <div style="display:flex; gap:5px; margin-top:5px;">
            <button type="button" class="btn-apply-div" style="flex:2; margin-top:0;" onclick="chotChiaKhoang()">✓ Áp Dụng Chia Khoang</button>
            <button type="button" class="btn-apply-div" style="flex:1; margin-top:0; background:#d9534f;" onclick="xoaChiaVungNay()">↺ Xóa Đợt</button>
          </div>
          <div class="note" style="margin-top:4px;color:#1b5e20;">* Rê chuột chọn khoang -> Click chọn -> Nhập số đợt -> Nhấn <b>TAB</b> đổi vị trí (Dưới / Giữa / Trên) -> Nhấn <b>Enter</b>.</div>
        </div>

        <div class="ext-panel" id="ext_panel">
          <div class="ext-header">
            <span class="ext-title" id="ext_tam_title">Tấm đang chọn: -</span>
            <button type="button" class="ext-close" onclick="dongBangChiTietTam()" title="Thoát chỉnh tấm">✕</button>
          </div>
          <input type="hidden" id="ext_base_name">
          <input type="hidden" id="ext_default_day">
          <div class="ext-row" id="row_ext_day">
            <label>Độ dày tấm</label>
            <input type="number" id="ext_day" value="17" min="0" onchange="capNhatChiTietTam()">
          </div>
          <div class="ext-row">
            <label>Số lớp</label>
            <input type="number" id="ext_lop" value="1" min="1" max="10" onchange="capNhatChiTietTam()">
          </div>
          <div class="ext-row">
            <label>Tấm</label>
            <input type="text" id="ext_tam_str" value="17" onchange="capNhatTuChuoiTam()">
          </div>
          <div style="display:flex; gap:5px; margin-top:5px;">
            <button type="button" class="btn-apply-div" style="flex:1; margin-top:0; background:#d9534f;" onclick="xoaTamDangChonUI()" title="Xóa luôn tấm đang chọn (Phím tắt: Delete)">🗑 Xóa Tấm (Del)</button>
            <button type="button" class="btn-apply-div" style="flex:1; margin-top:0; background:#6c757d;" onclick="khoiPhucTatCaTam()" title="Hiện lại toàn bộ các tấm đã xóa">↺ Khôi Phục</button>
          </div>
          <div class="note" style="margin-top:3px;">* Click vào tấm bất kỳ rồi gõ số + <b>Enter</b>, hoặc nhấn phím <b>Delete</b> để xóa luôn tấm đó.</div>
        </div>

        <div class="row"><label>Chiều Dài (mm):</label><input type="number" id="dai" value="1630" onchange="tuDongCapNhat()"></div>
        <div class="row"><label>Chiều Cao (mm):</label><input type="number" id="cao" value="2350" onchange="tuDongCapNhat()"></div>
        <div class="row"><label>Chiều Rộng/Sâu (mm):</label><input type="number" id="rong" value="600" onchange="tuDongCapNhat()"></div>
        <div class="row"><label>Độ dày ván chính (mm):</label><input type="number" id="day_van" value="17" onchange="tuDongCapNhat()"></div>
        <hr>
        <div class="row">
          <label class="chk-item" style="flex:1;font-weight:bold;color:#005a9e;">
            <span>Cánh tủ:</span>
            <input type="checkbox" id="co_canh" onchange="doiTuyChon()">
          </label>
          <div style="width:125px;display:flex;align-items:center;">
            <label id="wrap_an_canh" class="chk-item" style="display:none;color:#d9534f;font-weight:bold;">
              <span>Ẩn cánh</span>
              <input type="checkbox" id="an_canh" onchange="tuDongCapNhat()">
            </label>
          </div>
        </div>
        <div class="row">
          <label>Kiểu cánh:</label>
          <select id="kieu_canh" onchange="doiTuyChon()">
            <option value="trum">Cánh trùm</option>
            <option value="lot">Cánh lọt</option>
          </select>
        </div>
        <div class="row" id="row_lui_canh_lot" style="display:none;">
          <label style="color:#005a9e;">Thụt cánh lọt (mm):</label>
          <input type="number" id="lui_canh_lot" value="20" onchange="tuDongCapNhat()">
        </div>
        <div class="sub-box" id="box_thong_so_canh" style="display:none;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; cursor:pointer;" onclick="batTatKheCanh()">
            <span class="sub-title" style="margin-bottom:0;">Thông số cánh</span>
            <button type="button" id="btn_toggle_khe_canh" style="width:20px; height:18px; line-height:14px; text-align:center; background:#dce8f5; border:1px solid #9ec2e6; color:#005a9e; font-size:13px; font-weight:bold; border-radius:3px; padding:0; cursor:pointer;">+</button>
          </div>
          <div class="row"><label>Số cánh:</label><input type="number" id="so_canh" value="2" min="1" max="10" onchange="tuDongCapNhat()"></div>
          <div id="wrap_khe_ho_canh" style="display:none; margin-top:4px; padding-top:4px; border-top:1px dashed #b8d0e8;">
            <div class="row"><label>Cách trái (mm):</label><input type="number" id="cach_trai" value="2" onchange="tuDongCapNhat()"></div>
            <div class="row"><label>Cách phải (mm):</label><input type="number" id="cach_phai" value="2" onchange="tuDongCapNhat()"></div>
            <div class="row"><label>Cách trên (mm):</label><input type="number" id="cach_tren" value="2" onchange="tuDongCapNhat()"></div>
            <div class="row"><label>Cách dưới (mm):</label><input type="number" id="cach_duoi" value="2" onchange="tuDongCapNhat()"></div>
            <div class="row"><label>Khe cánh (mm):</label><input type="number" id="khe_canh" value="3" onchange="tuDongCapNhat()"></div>
          </div>
        </div>
        <hr>
        <div class="row">
          <label>Kiểu hậu:</label>
          <select id="kieu_hau" onchange="doiTuyChon()">
            <option value="cai_hong">Cài hông</option>
            <option value="cai_het_khung">Cài hết khung</option>
            <option value="lot_long">Lọt lòng</option>
            <option value="khong_hau">Không hậu</option>
          </select>
        </div>
        <div class="row" id="row_day_hau"><label>Độ dày ván hậu (mm):</label><input type="number" id="day_hau" value="9" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_lui_hau"><label>Lùi hậu (mm):</label><input type="number" id="lui_hau" value="10" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_am_ranh_hau"><label id="lbl_am_ranh">Âm rãnh hậu 4 bên (mm):</label><input type="number" id="am_ranh_hau" value="8" onchange="tuDongCapNhat()"></div>
        <hr>
        <div class="row">
          <label>Kiểu hông (Trùm):</label>
          <div class="chk-group">
            <label class="chk-item"><input type="checkbox" id="hong_trai_trum" checked onchange="tuDongCapNhat()"> Trái</label>
            <label class="chk-item"><input type="checkbox" id="hong_phai_trum" checked onchange="tuDongCapNhat()"> Phải</label>
          </div>
        </div>
        <div class="row">
          <label>Kiểu chân tủ:</label>
          <select id="kieu_chan" onchange="doiTuyChon()">
            <option value="khung_go">Khung gỗ</option>
            <option value="chan_nhua">Chân nhựa</option>
            <option value="khong">Không</option>
          </select>
        </div>
        <div class="row" id="row_cao_chan"><label>Chiều cao khung đáy (mm):</label><input type="number" id="cao_chan" value="100" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_lui_chan_truoc"><label>Lùi chân trước (mm):</label><input type="number" id="lui_chan_truoc" value="2" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_lui_chan_sau"><label>Lùi chân sau (mm):</label><input type="number" id="lui_chan_sau" value="25" onchange="tuDongCapNhat()"></div>
        <hr>
        <div class="row">
          <label>Kiểu nóc:</label>
          <select id="kieu_noc" onchange="doiTuyChon()">
            <option value="ha_noc">Hạ nóc</option>
            <option value="noc_lot">Nóc lọt</option>
            <option value="noc_trum">Nóc trùm</option>
          </select>
        </div>
        <div class="row" id="row_ho_noc"><label>Khoảng hở nóc (mm):</label><input type="number" id="ho_noc" value="50" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_lui_noc"><label>Lùi nóc (mm):</label><input type="number" id="lui_noc" value="2" onchange="tuDongCapNhat()"></div>
        <div class="row" id="row_ban_chan_noc"><label>Bản thanh chặn nóc (mm):</label><input type="number" id="ban_chan_noc" value="70" onchange="tuDongCapNhat()"></div>

        <div class="btn-group">
          <button type="button" class="action-btn btn-create" onclick="guiLenh('tao_moi')">+ Tạo Tủ Mới</button>
          <button type="button" class="action-btn btn-update" onclick="guiLenh('cap_nhat')">Cập Nhật Tủ</button>
        </div>
        <div class="note">* Tích <b>Trái / Phải</b> ở Kiểu hông để trùm hông, bỏ tích để hông gối lên đáy.</div><div style="margin-top:6px;"><div style="display:flex;gap:6px;margin-top:6px;"><button type="button" onclick="sketchup.luuMauHienTai()" style="flex:1;padding:7px 4px;background:#f59e0b;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:11.5px;cursor:pointer;">💾 Lưu Mẫu Vào Thư Viện</button><button type="button" onclick="sketchup.addSettingTuChon()" style="flex:1;padding:7px 4px;background:#0ea5e9;color:#fff;border:none;border-radius:4px;font-weight:600;font-size:11.5px;cursor:pointer;">⚙ Add Setting</button></div></div>
      </body>
    HTML
    js = <<~JS
      <script>
      const MAU_TU_AO_CHUAN = {
        dai: 1630, cao: 2350, rong: 600, day_van: 17,
        co_canh: false, an_canh: false, kieu_canh: 'trum', lui_canh_lot: 20,
        so_canh: 2, cach_trai: 2, cach_phai: 2, cach_tren: 2, cach_duoi: 2, khe_canh: 3,
        kieu_hau: 'cai_het_khung', day_hau: 9, lui_hau: 10, am_ranh_hau: 8,
        hong_trai_trum: true, hong_phai_trum: true,
        kieu_chan: 'khung_go', cao_chan: 100, lui_chan_truoc: 2, lui_chan_sau: 25,
        kieu_noc: 'ha_noc', ho_noc: 50, lui_noc: 2, ban_chan_noc: 70
      };
      function chonMauTuAo() { napThongSo(MAU_TU_AO_CHUAN); tuDongCapNhat(); }
      function chonUuTienVach(ben) {
        document.getElementById('div_vach_trai').checked = (ben === 'trai');
        document.getElementById('div_vach_phai').checked = (ben === 'phai');
        moPhongChiaKhoang();
      }
      function chonUuTienDot(phia) {
        document.getElementById('div_dot_tren').checked = (phia === 'tren');
        document.getElementById('div_dot_duoi').checked = (phia === 'duoi');
        moPhongChiaKhoang();
      }
      function batTatChiaKhoang() {
        const btn = document.getElementById('btn_chia_khoang');
        const panel = document.getElementById('div_panel');
        if (btn.classList.contains('active-tool')) {
          btn.classList.remove('active-tool'); panel.style.display = 'none'; sketchup.tatToolChiaKhoang();
        } else {
          thoatCheDoChinhTam(); btn.classList.add('active-tool'); panel.style.display = 'none'; sketchup.batToolChiaKhoang();
        }
      }
      function hienBangChiaChoVung(data) {
        document.getElementById('btn_chia_khoang').classList.add('active-tool');
        document.getElementById('div_panel').style.display = 'block';
        document.getElementById('div_region_path').value = data.path || 'root';
        document.getElementById('div_region_title').innerText = 'Chia Khoang (' + (data.path || 'root') + ')';
        document.getElementById('div_vach_expr').value = '';
        const utVach = data.vach_uu_tien || 'trai';
        document.getElementById('div_vach_trai').checked = (utVach === 'trai');
        document.getElementById('div_vach_phai').checked = (utVach === 'phai');
        document.getElementById('div_vach_lui').value = data.vach_lui || 0;
        document.getElementById('div_dot_expr').value = '';
        const utDot = data.dot_uu_tien || 'duoi';
        document.getElementById('div_dot_tren').checked = (utDot === 'tren');
        document.getElementById('div_dot_duoi').checked = (utDot === 'duoi');
        document.getElementById('div_dot_lui').value = data.dot_lui || 0;
      }
      function dongBangChiaKhoang() {
        document.getElementById('btn_chia_khoang').classList.remove('active-tool');
        document.getElementById('div_panel').style.display = 'none'; sketchup.tatToolChiaKhoang();
      }
      function thoatCheDoChiaKhoang() {
        document.getElementById('btn_chia_khoang').classList.remove('active-tool');
        document.getElementById('div_panel').style.display = 'none';
      }
      function layPayloadChiaKhoang() {
        return {
          path: document.getElementById('div_region_path').value || 'root',
          vach_expr: document.getElementById('div_vach_expr').value.trim(),
          vach_uu_tien: document.getElementById('div_vach_phai').checked ? 'phai' : 'trai',
          vach_lui: parseFloat(document.getElementById('div_vach_lui').value) || 0,
          dot_expr: document.getElementById('div_dot_expr').value.trim(),
          dot_uu_tien: document.getElementById('div_dot_tren').checked ? 'tren' : 'duoi',
          dot_lui: parseFloat(document.getElementById('div_dot_lui').value) || 0
        };
      }
      function moPhongChiaKhoang() { sketchup.moPhongChiaKhoang(JSON.stringify(layPayloadChiaKhoang())); }
      function chotChiaKhoang() {
        const payload = layPayloadChiaKhoang();
        if (!payload.vach_expr && !payload.dot_expr) return;
        sketchup.capNhatChiaKhoang(JSON.stringify(payload));
        document.getElementById('div_vach_expr').value = ''; document.getElementById('div_dot_expr').value = '';
      }
      function xoaChiaVungNay() {
        const path = document.getElementById('div_region_path').value || 'root';
        sketchup.xoaChiaVung(path);
        document.getElementById('div_vach_expr').value = ''; document.getElementById('div_dot_expr').value = '';
      }
      function batTatMoRong() {
        const btn = document.getElementById('btn_mo_rong');
        if (btn.classList.contains('active-tool')) { sketchup.tatToolMoRong(); }
        else { thoatCheDoChiaKhoang(); btn.classList.add('active-tool'); sketchup.batToolMoRong(); }
      }
      function thoatCheDoChinhTam() {
        document.getElementById('btn_mo_rong').classList.remove('active-tool');
        document.getElementById('ext_panel').style.display = 'none';
      }
      function anBangChiTietTamSauKhiXoa() {
        document.getElementById('ext_tam_title').innerText = 'Tấm đang chọn: (Đã xóa)';
        document.getElementById('ext_base_name').value = '';
      }
      function xoaTamDangChonUI() {
        const baseName = document.getElementById('ext_base_name').value;
        if (baseName) sketchup.xoaTamDangChon(baseName);
      }
      function khoiPhucTatCaTam() { sketchup.khoiPhucTatCaTam(); }
      function hienChiTietTam(data) {
        thoatCheDoChiaKhoang();
        document.getElementById('btn_mo_rong').classList.add('active-tool');
        document.getElementById('ext_panel').style.display = 'block';
        document.getElementById('ext_tam_title').innerText = 'Tấm đang chọn: ' + data.base_name;
        document.getElementById('ext_base_name').value = data.base_name;
        document.getElementById('ext_default_day').value = data.default_day;
        document.getElementById('ext_day').value = data.day;
        document.getElementById('ext_lop').value = data.lop;
        document.getElementById('ext_tam_str').value = data.tam_str;
        document.getElementById('row_ext_day').style.display = (data.lop > 1) ? 'none' : 'flex';
      }
      function dongBangChiTietTam() { sketchup.tatToolMoRong(); }
      function capNhatChiTietTam() {
        const baseName = document.getElementById('ext_base_name').value;
        const defaultDay = parseFloat(document.getElementById('ext_default_day').value) || 17;
        let lop = parseInt(document.getElementById('ext_lop').value) || 1;
        if (lop < 1) { lop = 1; document.getElementById('ext_lop').value = 1; }
        const rowDay = document.getElementById('row_ext_day');
        let day = parseFloat(document.getElementById('ext_day').value);
        if (isNaN(day)) day = defaultDay;
        let lopDays = []; let tamStr = '';
        if (lop > 1) {
          rowDay.style.display = 'none';
          for (let i = 0; i < lop; i++) { lopDays.push(defaultDay); }
          tamStr = lopDays.join('/');
        } else {
          rowDay.style.display = 'flex'; lopDays = [day]; tamStr = day.toString();
        }
        document.getElementById('ext_tam_str').value = tamStr;
        sketchup.capNhatTamRieng(JSON.stringify({ base_name: baseName, day: day, lop: lop, lop_days: lopDays }));
      }
      function capNhatTuChuoiTam() {
        const baseName = document.getElementById('ext_base_name').value;
        const defaultDay = parseFloat(document.getElementById('ext_default_day').value) || 17;
        const rawStr = document.getElementById('ext_tam_str').value.trim();
        let parts = rawStr.split('/').map(s => parseFloat(s.trim())).filter(n => !isNaN(n) && n >= 0);
        if (parts.length === 0) parts = [defaultDay];
        const lop = parts.length;
        const tongDay = parts.reduce((a, b) => a + b, 0);
        document.getElementById('ext_lop').value = lop;
        document.getElementById('ext_day').value = tongDay;
        document.getElementById('ext_tam_str').value = parts.join('/');
        document.getElementById('row_ext_day').style.display = (lop > 1) ? 'none' : 'flex';
        sketchup.capNhatTamRieng(JSON.stringify({ base_name: baseName, day: tongDay, lop: lop, lop_days: parts }));
      }
      function batTatKheCanh() {
        const wrap = document.getElementById('wrap_khe_ho_canh');
        const btn = document.getElementById('btn_toggle_khe_canh');
        if (wrap.style.display === 'none') { wrap.style.display = 'block'; btn.innerText = '-'; }
        else { wrap.style.display = 'none'; btn.innerText = '+'; }
      }
      function anHienGiaoDien() {
        const coCanh = document.getElementById('co_canh').checked;
        document.getElementById('box_thong_so_canh').style.display = coCanh ? 'block' : 'none';
        document.getElementById('wrap_an_canh').style.display = coCanh ? 'flex' : 'none';
        if (!coCanh) document.getElementById('an_canh').checked = false;
        const kieu = document.getElementById('kieu_canh').value;
        document.getElementById('row_lui_canh_lot').style.display = (kieu === 'lot') ? 'flex' : 'none';
        const hau = document.getElementById('kieu_hau').value;
        const coHau = (hau !== 'khong_hau');
        document.getElementById('row_day_hau').style.display = coHau ? 'flex' : 'none';
        document.getElementById('row_lui_hau').style.display = coHau ? 'flex' : 'none';
        document.getElementById('row_am_ranh_hau').style.display = (hau === 'cai_hong' || hau === 'cai_het_khung') ? 'flex' : 'none';
        document.getElementById('lbl_am_ranh').innerText = (hau === 'cai_het_khung') ? 'Âm rãnh hậu 4 bên (mm):' : 'Âm rãnh hậu 2 bên (mm):';
        const chan = document.getElementById('kieu_chan').value;
        document.getElementById('row_cao_chan').style.display = (chan === 'khong') ? 'none' : 'flex';
document.getElementById('row_lui_chan_truoc').style.display = (chan === 'khong') ? 'none' : 'flex';
document.getElementById('row_lui_chan_sau').style.display = (chan === 'khung_go') ? 'flex' : 'none';
const noc = document.getElementById('kieu_noc').value;
const laHaNoc = (noc === 'ha_noc') ? 'flex' : 'none';
document.getElementById('row_ho_noc').style.display = laHaNoc;
document.getElementById('row_lui_noc').style.display = laHaNoc;
document.getElementById('row_ban_chan_noc').style.display = laHaNoc;
}
function doiTuyChon() { anHienGiaoDien(); tuDongCapNhat(); }
function layDuLieu() {
return {
dai: document.getElementById('dai').value, cao: document.getElementById('cao').value,
rong: document.getElementById('rong').value, day_van: document.getElementById('day_van').value,
co_canh: document.getElementById('co_canh').checked, an_canh: document.getElementById('an_canh').checked,
kieu_canh: document.getElementById('kieu_canh').value, lui_canh_lot: document.getElementById('lui_canh_lot').value,
so_canh: document.getElementById('so_canh').value, cach_trai: document.getElementById('cach_trai').value,
cach_phai: document.getElementById('cach_phai').value, cach_tren: document.getElementById('cach_tren').value,
cach_duoi: document.getElementById('cach_duoi').value, khe_canh: document.getElementById('khe_canh').value,
kieu_hau: document.getElementById('kieu_hau').value, day_hau: document.getElementById('day_hau').value,
lui_hau: document.getElementById('lui_hau').value, am_ranh_hau: document.getElementById('am_ranh_hau').value,
hong_trai_trum: document.getElementById('hong_trai_trum').checked,
hong_phai_trum: document.getElementById('hong_phai_trum').checked,
kieu_chan: document.getElementById('kieu_chan').value, cao_chan: document.getElementById('cao_chan').value,
lui_chan_truoc: document.getElementById('lui_chan_truoc').value, lui_chan_sau: document.getElementById('lui_chan_sau').value,
kieu_noc: document.getElementById('kieu_noc').value, ho_noc: document.getElementById('ho_noc').value,
lui_noc: document.getElementById('lui_noc').value, ban_chan_noc: document.getElementById('ban_chan_noc').value
};
}
function guiLenh(hanhDong) { sketchup.xuLyTu(hanhDong, JSON.stringify(layDuLieu())); }
function tuDongCapNhat() { sketchup.xuLyTu('tu_dong_cap_nhat', JSON.stringify(layDuLieu())); }
function napThongSo(data) {
for (let key in data) {
const el = document.getElementById(key);
if (el && data[key] !== undefined) {
if (el.type === 'checkbox') el.checked = !!data[key];
else el.value = data[key];
}
}
anHienGiaoDien();
}
anHienGiaoDien();
      </script>
      </html>
    JS
html_phan_than + js
end
  def self.tim_tu_dang_chon
    sel = Sketchup.active_model.selection
    unless sel.empty?
      target = sel.first
      if target.is_a?(Sketchup::Group)
        return target if target.attribute_dictionary('TuAoConfig')
        if target.parent.is_a?(Sketchup::ComponentDefinition)
          parent_inst = target.parent.instances.first
          return parent_inst if parent_inst && parent_inst.attribute_dictionary('TuAoConfig')
        end
      end
    end
    (@current_tu_group && @current_tu_group.valid?) ? @current_tu_group : nil
  end

  def self.mo_bang_dieu_khien
    @dialog.close if @dialog && @dialog.visible?

    @dialog = UI::HtmlDialog.new({
      :dialog_title => "T2MS-Mod",
      :preferences_key => "T2MSModDialog",
      :scrollable => true,
      :resizable => true,
      :width => 295,
      :height => 740,
      :style => UI::HtmlDialog::STYLE_DIALOG
    })

    @dialog.set_html(self.tao_html_giao_dien)

    @dialog.add_action_callback("xuLyTu") do |action_context, hanh_dong, json_str|
      next if @is_updating
      require 'json'
      params = JSON.parse(json_str)
      model = Sketchup.active_model
      sel = model.selection
      @is_updating = true
      begin
        if hanh_dong == 'tao_moi'
          model.start_operation('T2MS-Mod: Tạo Tủ Mới', true)
          tu_group = model.active_entities.add_group
          self.cap_nhat_tu(tu_group, params)
          @current_tu_group = tu_group
          sel.clear
          sel.add(tu_group)
          model.commit_operation
        else
          tu_group = self.tim_tu_dang_chon
          if tu_group && tu_group.valid?
            model.start_operation('T2MS-Mod: Cập Nhật Tủ', true)
            self.cap_nhat_tu(tu_group, params)
            model.commit_operation
          elsif hanh_dong == 'cap_nhat'
            UI.messagebox("Vui lòng click chọn một thùng tủ đã tạo bằng T2MS-Mod trước khi bấm Cập Nhật!")
          end
        end
      rescue => e
        model.abort_operation
        puts "Loi T2MS-Mod: #{e.message}"
      ensure
        @is_updating = false
      end
    end

    @dialog.add_action_callback("batToolChiaKhoang") do |action_context|
      tu_group = self.tim_tu_dang_chon || @current_tu_group
      if tu_group && tu_group.valid?
        params = self.lay_thong_so_tu_group(tu_group)
        self.cap_nhat_tu(tu_group, params) if params
      end
      @active_chia_tool = ChiaKhoangTool.new(tu_group)
      Sketchup.active_model.select_tool(@active_chia_tool)
    end

    @dialog.add_action_callback("tatToolChiaKhoang") do |action_context|
      @active_chia_tool = nil
      Sketchup.active_model.select_tool(nil)
      self.thong_bao_thoat_chia_khoang
    end

    @dialog.add_action_callback("moPhongChiaKhoang") do |action_context, json_str|
      require 'json'
      data = JSON.parse(json_str)
      if @active_chia_tool && Sketchup.active_model.tools.active_tool == @active_chia_tool
        @active_chia_tool.set_preview(data)
      end
    end

    @dialog.add_action_callback("capNhatChiaKhoang") do |action_context, json_str|
      require 'json'
      data = JSON.parse(json_str)
      tu_group = self.tim_tu_dang_chon || @current_tu_group
      if tu_group && tu_group.valid?
        if @active_chia_tool && Sketchup.active_model.tools.active_tool == @active_chia_tool
          cur_preview = @active_chia_tool.instance_variable_get(:@preview_data)
          data['align_mode'] = cur_preview['align_mode'] if cur_preview && cur_preview['align_mode']
          @active_chia_tool.clear_selection
        end
        self.chot_ap_dung_preview(tu_group, data['path'], data)
        Sketchup.active_model.active_view.invalidate
      end
    end

    @dialog.add_action_callback("xoaChiaVung") do |action_context, path|
      tu_group = self.tim_tu_dang_chon || @current_tu_group
      if tu_group && tu_group.valid?
        @active_chia_tool.clear_selection if @active_chia_tool
        self.xoa_chia_vung(tu_group, path)
        Sketchup.active_model.active_view.invalidate
      end
    end

    @dialog.add_action_callback("batToolMoRong") do |action_context|
      tu_group = self.tim_tu_dang_chon
      sel = Sketchup.active_model.selection
      tam_ban_dau = (!sel.empty? && sel.first.is_a?(Sketchup::Group) && sel.first.attribute_dictionary('TamConfig')) ? sel.first : nil
      Sketchup.active_model.select_tool(ChonTamTool.new(tu_group, tam_ban_dau))
      self.hien_bang_chi_tiet_tam(tu_group, tam_ban_dau) if tu_group && tam_ban_dau
    end

    @dialog.add_action_callback("tatToolMoRong") do |action_context|
      Sketchup.active_model.select_tool(nil)
      self.thong_bao_thoat_chinh_tam
    end

    @dialog.add_action_callback("xoaTamDangChon") do |action_context, base_name|
      tu_group = self.tim_tu_dang_chon || @current_tu_group
      self.xoa_tam_dang_chon(tu_group, base_name) if tu_group && tu_group.valid?
    end

    @dialog.add_action_callback("khoiPhucTatCaTam") do |action_context|
      tu_group = self.tim_tu_dang_chon || @current_tu_group
      self.khoi_phuc_tat_ca_tam_da_xoa(tu_group) if tu_group && tu_group.valid?
    end

    @dialog.add_action_callback("capNhatTamRieng") do |action_context, json_str|
      next if @is_updating
      require 'json'
      data = JSON.parse(json_str)
      tu_group = self.tim_tu_dang_chon
      if tu_group && tu_group.valid?
        model = Sketchup.active_model
        @is_updating = true
        begin
          model.start_operation('T2MS-Mod: Sửa Tấm Ván', true)
          custom_parts = JSON.parse(tu_group.get_attribute('TuAoConfig', 'custom_parts', '{}')) rescue {}
          custom_parts[data['base_name']] = { 'day' => data['day'].to_f, 'lop' => data['lop'].to_i, 'lop_days' => data['lop_days'] }
          tu_group.set_attribute('TuAoConfig', 'custom_parts', custom_parts.to_json)

          params = self.lay_thong_so_tu_group(tu_group)
          self.cap_nhat_tu(tu_group, params) if params
          model.commit_operation
        rescue => e
          model.abort_operation
          puts "Loi Cap Nhat Tam: #{e.message}"
        ensure
          @is_updating = false
        end
      end
    end

@dialog.add_action_callback("kiemTraUpdateNet") { |ctx| self.kiem_tra_va_cap_nhat_plugin }
    @dialog.add_action_callback("moThuVien") do |action_context|
  self.mo_cua_so_thu_vien
end

@dialog.add_action_callback("luuMauHienTai") do |action_context|
  tu_group = self.tim_tu_dang_chon || @current_tu_group
  if tu_group && tu_group.valid? && tu_group.attribute_dictionary('TuAoConfig')
    self.luu_mau_vao_thu_vien(tu_group)
  else
    UI.messagebox("Vui lòng click chọn một thùng tủ T2MS-Mod trước khi bấm Lưu Mẫu!")
  end
end

@dialog.show
  end

  class TuSelectionObserver < Sketchup::SelectionObserver
    def onSelectionBulkChange(selection)
      TuAoThamSo.dong_bo_bang_voi_selection
    end
  end

  def self.dong_bo_bang_voi_selection
    return if @is_updating
    return unless @dialog && @dialog.visible?
    return if @active_chia_tool && Sketchup.active_model.tools.active_tool == @active_chia_tool
    require 'json'

    sel = Sketchup.active_model.selection
    if !sel.empty? && sel.first.is_a?(Sketchup::Group) && sel.first.attribute_dictionary('TamConfig')
      tu_group = self.tim_tu_dang_chon
      if tu_group
        @current_tu_group = tu_group
        self.hien_bang_chi_tiet_tam(tu_group, sel.first)
      end
    end

    data = self.lay_thong_so_tu_selection
    @dialog.execute_script("napThongSo(#{data.to_json})") if data
  end

  unless file_loaded?('T2MS_Mod_Menu')
    Sketchup.active_model.selection.add_observer(TuSelectionObserver.new)
    cmd = UI::Command.new("T2MS-Mod") { self.mo_bang_dieu_khien }
    cmd.tooltip = "T2MS-Mod - Thiết kế tủ áo tham số"
    cmd.status_bar_text = "Mở bảng điều khiển thiết kế tủ áo thông minh T2MS-Mod"
    cmd.menu_text = "T2MS-Mod"
    icon_dir = File.join(Sketchup.find_support_file("Plugins"), "T2MS_Mod_Library")
    icon_tu  = File.join(icon_dir, "icon_tu_chuan.png")
    begin
      r1 = Sketchup::ImageRep.new
      b1 = Array.new(32 * 32 * 4, 0)
      p1 = lambda { |x, y| next if x < 0 || x > 31 || y < 0 || y > 31; i = (y * 32 + x) * 4; b1[i] = 45; b1[i+1] = 45; b1[i+2] = 45; b1[i+3] = 255 }
      (5..23).each do |y|
        (6..25).each do |x|
          is_line = (x == 6 || x == 7 || x == 24 || x == 25 || y == 5 || y == 6 || y == 22 || y == 23 || x == 15 || x == 16)
          p1.call(x, y) if is_line
        end
      end
      (12..16).each { |y| [12, 13, 18, 19].each { |x| p1.call(x, y) } }
      (24..27).each { |y| [8, 9, 22, 23].each { |x| p1.call(x, y) } }
      r1.set_data(32, 32, 32, 0, b1.pack("C*"))
      r1.save_file(icon_tu)
      cmd.small_icon = icon_tu
      cmd.large_icon = icon_tu
    rescue; end
    UI.menu("Plugins").add_item(cmd)
    toolbar = UI::Toolbar.new("T2MS-Mod")
    toolbar.add_item(cmd)
    cmd_upd = UI::Command.new("Cập nhật & Tạo Icon") { self.cap_nhat_va_tao_icon_tu }
    cmd_upd.tooltip = "Cập nhật thông số & Tạo Icon mẫu tủ"
    cmd_upd.status_bar_text = "Đồng bộ thông số thùng tủ đang chọn và tạo ảnh Icon đại diện"
    icon_upd = File.join(icon_dir, "icon_cap_nhat.png")
    begin
      r2 = Sketchup::ImageRep.new
      b2 = Array.new(32 * 32 * 4, 0)
      p2 = lambda { |x, y| next if x < 0 || x > 31 || y < 0 || y > 31; i = (y * 32 + x) * 4; b2[i] = 45; b2[i+1] = 45; b2[i+2] = 45; b2[i+3] = 255 }
      (6..19).each { |y| [15, 16].each { |x| p2.call(x, y) } }
      (0..5).each { |k| [15 - k, 16 - k, 15 + k, 16 + k].each { |x| p2.call(x, 19 - k); p2.call(x, 20 - k) } }
      (19..25).each { |y| [7, 8, 23, 24].each { |x| p2.call(x, y) } }
      (7..24).each { |x| [24, 25].each { |y| p2.call(x, y) } }
      r2.set_data(32, 32, 32, 0, b2.pack("C*"))
      r2.save_file(icon_upd)
      cmd_upd.small_icon = icon_upd
      cmd_upd.large_icon = icon_upd
    rescue; end
    toolbar.add_item(cmd_upd)
    toolbar.show
    file_loaded('T2MS_Mod_Menu')
  end
end
