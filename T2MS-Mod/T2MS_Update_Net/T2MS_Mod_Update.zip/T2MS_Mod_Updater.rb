require 'json'
require 'net/http'
require 'openssl'
require 'uri'
require 'fileutils'
require 'zip'

module TuAoThamSo
  CURRENT_VERSION    = 'Ver 1.01'
  DEFAULT_UPDATE_URL = 'https://raw.githubusercontent.com/T2MS-Admin/Plugin-T2MS/main/T2MS-Mod/T2MS_Update_Net/version.json'
  ADMIN_PIN          = '@TTMS01060211'
  ADMIN_RELEASE_DIR  = (Dir.exist?('D:/T2MS-Admin/T2MS-Mod') ? 'D:/T2MS-Admin/T2MS-Mod/T2MS_Update_Net' : File.join(Dir.home.tr('\\', '/'), 'Desktop', 'T2MS_Update_Net'))

  def self.la_may_admin?
    Dir.exist?('D:/T2MS-Admin/T2MS-Mod')
  end

  def self.xac_thuc_admin_va_xuat_ban
    unless self.la_may_admin?
      res = UI.inputbox(['Nhập mật khẩu Admin để mở khóa:'], [''], 'Xác thực quyền Admin T2MS-Mod')
      return unless res
      if res.at(0).to_s.strip != ADMIN_PIN
        UI.messagebox('Sai mật khẩu Admin! Bạn không có quyền truy cập chức năng này.')
        return
      end
    end
    self.xuat_ban_update_admin
  end

  def self.cau_hinh_update_path
    File.join(__dir__, 'T2MS_Mod_Library', 'update_source.json')
  end

  def self.lay_nguon_cap_nhat
    p = self.cau_hinh_update_path
    if File.exist?(p)
      data = JSON.parse(File.read(p, encoding: 'UTF-8')) rescue {}
      url = data['source_url'].to_s.strip
      return url unless url.empty?
    end
    DEFAULT_UPDATE_URL
  end

  def self.tai_noi_dung_https(url_str, limit = 5)
    raise 'Quá nhiều lần chuyển hướng URL!' if limit <= 0
    uri = URI.parse(url_str.strip)
    http = Net::HTTP.new(uri.host, uri.port)
    if uri.scheme == 'https'
      http.use_ssl = true
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    end
    http.open_timeout = 8
    http.read_timeout = 15
    req = Net::HTTP::Get.new(uri.request_uri)
    req['User-Agent'] = 'T2MS-Mod-Updater'
    res = http.request(req)
    case res
    when Net::HTTPSuccess then res.body
    when Net::HTTPRedirection then self.tai_noi_dung_https(res['location'], limit - 1)
    else raise 'Lỗi kết nối máy chủ: ' + res.code.to_s
    end
  end

  def self.kiem_tra_cap_nhat_ngam
    return if @da_check_update_phien_nay
    @da_check_update_phien_nay = true
    UI.start_timer(1.5, false) { self.kiem_tra_va_cap_nhat_plugin(true) }
  end

  def self.bao_trang_thai_nut_update(has_upd, ver_str)
    return unless @dialog && @dialog.visible?
    js = 'setUpdateAvailable(' + has_upd.to_s + ', ' + ver_str.to_json + ')'
    @dialog.execute_script(js)
  end

  def self.kiem_tra_va_cap_nhat_plugin(silent = false)
    src = self.lay_nguon_cap_nhat
    return if src.empty?
    begin
      raw_json = self.tai_noi_dung_https(src).force_encoding('UTF-8')
      meta     = JSON.parse(raw_json)
      new_ver  = meta['version'].to_s.strip
      zip_url  = meta['zip_url'].to_s.strip
      notes    = meta['notes'].to_s.strip
      if new_ver.empty? || new_ver == CURRENT_VERSION
        self.bao_trang_thai_nut_update(false, CURRENT_VERSION)
        UI.messagebox('Bạn đang dùng phiên bản mới nhất (' + CURRENT_VERSION + ')!') unless silent
        return
      end
      self.bao_trang_thai_nut_update(true, new_ver)
      return if silent
      msg = 'Đã có bản cập nhật mới: ' + new_ver + '
Phiên bản hiện tại: ' + CURRENT_VERSION + '

Nội dung nâng cấp:
' + notes + '

Bạn có muốn tải về và cập nhật ngay không?'
      return unless UI.messagebox(msg, MB_YESNO) == IDYES
      tmp_zip = File.join(Sketchup.temp_dir.tr('\\', '/'), 't2ms_net_update.zip')
      File.binwrite(tmp_zip, self.tai_noi_dung_https(zip_url))
      target_dir = File.expand_path(__dir__)
      Zip::File.open(tmp_zip) do |zf|
        zf.each do |entry|
          next if entry.directory?
          dest = File.join(target_dir, File.basename(entry.name.tr('\\', '/')))
          File.delete(dest) if File.exist?(dest)
          File.binwrite(dest, entry.get_input_stream.read)
        end
      end
      load File.join(target_dir, 'T2MS_Mod_Updater.rb')
      load File.join(target_dir, 'T2MS_Mod_Lib.rb')
      ['T2MS_Mod_Main.rb', 'T2MS_Mod.rb'].each { |m| mp = File.join(target_dir, m); load mp if File.exist?(mp) }
      self.bao_trang_thai_nut_update(false, new_ver)
      UI.messagebox('Cập nhật thành công lên phiên bản ' + new_ver + '!')
    rescue => e
      UI.messagebox('Lỗi cập nhật:
' + e.message) unless silent
    end
  end

  def self.xuat_ban_update_admin
    next_ver = CURRENT_VERSION.sub(/(\d+)$/) { |m| format('%0' + m.length.to_s + 'd', m.to_i + 1) }
    next_ver = 'Ver 1.04' if next_ver == CURRENT_VERSION
    res = UI.inputbox(['Số phiên bản phát hành mới:', 'Ghi chú nội dung nâng cấp:', 'Thư mục xuất gói cập nhật:'], [next_ver, 'Nâng cấp tính năng mới và tối ưu hiệu năng.', ADMIN_RELEASE_DIR], 'Admin - Xuất bản cập nhật T2MS-Mod')
    return unless res
    new_ver = res.at(0).to_s.strip
    notes   = res.at(1).to_s.strip
    out_dir = res.at(2).to_s.strip.tr('\\', '/')
    return if new_ver.empty? || out_dir.empty?
    p_dir  = File.expand_path(__dir__)
    upd_f  = File.join(p_dir, 'T2MS_Mod_Updater.rb')
    main_f = File.exist?(File.join(p_dir, 'T2MS_Mod_Main.rb')) ? File.join(p_dir, 'T2MS_Mod_Main.rb') : File.join(p_dir, 'T2MS_Mod.rb')
    uc = File.read(upd_f, encoding: 'UTF-8')
    uc.sub!(/CURRENT_VERSION\s*=\s*'.*?'/, "CURRENT_VERSION    = '#{new_ver}'")
    File.write(upd_f, uc, encoding: 'UTF-8')
    mc = File.read(main_f, encoding: 'UTF-8')
    mc.gsub!(/Ver \d+\.\d+/, new_ver)
    File.write(main_f, mc, encoding: 'UTF-8')
    load upd_f
    load main_f
    FileUtils.mkdir_p(out_dir)
    zip_p = File.join(out_dir, 'T2MS_Mod_Update.zip')
    File.delete(zip_p) if File.exist?(zip_p)
    Zip::File.open(zip_p, create: true) do |zf|
      ['T2MS_Mod_Main.rb', 'T2MS_Mod.rb', 'T2MS_Mod_Lib.rb', 'T2MS_Mod_Updater.rb'].each do |f|
        src = File.join(p_dir, f)
        zf.add(f, src) if File.exist?(src)
      end
    end
    zip_raw_url = DEFAULT_UPDATE_URL.sub(/version\.json$/, 'T2MS_Mod_Update.zip')
    meta = { 'version' => new_ver, 'notes' => notes, 'zip_url' => zip_raw_url }
    File.write(File.join(out_dir, 'version.json'), JSON.pretty_generate(meta), encoding: 'UTF-8')
    UI.messagebox('Đã xuất bản thành công gói ' + new_ver + '!
Hãy kéo thả 2 tệp trong thư mục vừa mở lên GitHub.')
    system('explorer "' + out_dir.tr('/', '\\') + '"')
  end
end