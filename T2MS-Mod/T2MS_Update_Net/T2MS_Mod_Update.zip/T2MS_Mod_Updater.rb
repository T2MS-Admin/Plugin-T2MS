  require 'json'
  require 'net/http'
  require 'openssl'
  require 'uri'
  require 'fileutils'

  module TuAoThamSo
    CURRENT_VERSION    = 'Ver 1.01'
    DEFAULT_UPDATE_URL = 'https://raw.githubusercontent.com/T2MS-Admin/Plugin-T2MS/main/T2MS-Mod/T2MS_Update_Net/version.json'
    ADMIN_PIN          = '@TTMS01060211'

    def self.admin_release_dir
      return 'D:/T2MS-Admin/T2MS-Mod/T2MS_Update_Net' if Dir.exist?('D:/T2MS-Admin/T2MS-Mod')
      File.join(Dir.home.tr('\\', '/'), 'Desktop', 'T2MS_Update_Net')
    end

    def self.la_may_admin?
      Dir.exist?('D:/T2MS-Admin/T2MS-Mod')
    end

    def self.xac_thuc_admin_va_xuat_ban
      unless self.la_may_admin?
        res = UI.inputbox(['Nhập mật khẩu Admin để mở khóa:'], [''], 'Xác thực quyền Admin T2MS-Mod')
        return unless res
        if res.at(0).to_s.strip != ADMIN_PIN
          UI.messagebox('Sai mật khẩu Admin! Bạn không có quyền truy cập chức năng này.')
          return
        end
      end
      self.xuat_ban_update_admin
    end

    def self.cau_hinh_update_path
      File.join(__dir__, 'T2MS_Mod_Library', 'update_source.json')
    end

    def self.lay_nguon_cap_nhat
      p = self.cau_hinh_update_path
      if File.exist?(p)
        data = JSON.parse(File.read(p, encoding: 'UTF-8')) rescue {}
        url = data['source_url'].to_s.strip
        return url unless url.empty?
      end
      DEFAULT_UPDATE_URL
    end

    def self.tai_noi_dung_https(url_str, limit = 5)
      raise 'Quá nhiều lần chuyển hướng URL!' if limit <= 0
      uri = URI.parse(url_str.strip)
      http = Net::HTTP.new(uri.host, uri.port)
      if uri.scheme == 'https'
        http.use_ssl = true
        http.verify_mode = OpenSSL::SSL::VERIFY_NONE
      end
      http.open_timeout = 8
      http.read_timeout = 15
      req = Net::HTTP::Get.new(uri.request_uri)
      req['User-Agent'] = 'T2MS-Mod-Updater'
      res = http.request(req)
      case res
      when Net::HTTPSuccess then res.body
      when Net::HTTPRedirection then self.tai_noi_dung_https(res['location'], limit - 1)
      else raise "Lỗi kết nối máy chủ: #{res.code}"
      end
    end

    def self.kiem_tra_cap_nhat_ngam
      return if @da_check_update_phien_nay
      @da_check_update_phien_nay = true
      UI.start_timer(1.5, false) { self.kiem_tra_va_cap_nhat_plugin(true) }
    end

    def self.bao_trang_thai_nut_update(has_upd, ver_str)
      return unless @dialog && @dialog.visible?
      js = "setUpdateAvailable(#{has_upd}, #{ver_str.to_json})"
      @dialog.execute_script(js)
    end

    def self.ps_unzip(zip_path, dest_dir)
      FileUtils.rm_rf(dest_dir)
      FileUtils.mkdir_p(dest_dir)
      z_win = zip_path.tr('/', '\\')
      d_win = dest_dir.tr('/', '\\')
      cmd = %Q(powershell -NoProfile -Command "Expand-Archive -Path '#{z_win}' -DestinationPath '#{d_win}' -Force")
      system(cmd)
    end

    def self.ps_zip(src_folder, out_zip)
      File.delete(out_zip) if File.exist?(out_zip)
      s_win = src_folder.tr('/', '\\') + '\\*'
      z_win = out_zip.tr('/', '\\')
      cmd = %Q(powershell -NoProfile -Command "Compress-Archive -Path '#{s_win}' -DestinationPath '#{z_win}' -Force")
      system(cmd)
    end

    def self.kiem_tra_va_cap_nhat_plugin(silent = false)
      src = self.lay_nguon_cap_nhat
      return if src.empty?
      begin
        raw_json = self.tai_noi_dung_https(src).force_encoding('UTF-8')
        meta     = JSON.parse(raw_json)
        new_ver  = meta['version'].to_s.strip
        zip_url  = meta['zip_url'].to_s.strip
        notes    = meta['notes'].to_s.strip
        if new_ver.empty? || new_ver == CURRENT_VERSION
          self.bao_trang_thai_nut_update(false, CURRENT_VERSION)
          UI.messagebox("Bạn đang dùng phiên bản mới nhất (#{CURRENT_VERSION})!") unless silent
          return
        end
        self.bao_trang_thai_nut_update(true, new_ver)
        return if silent
        msg = "Đã có bản cập nhật mới: #{new_ver}\nPhiên bản hiện tại: #{CURRENT_VERSION}\n\nNội dung nâng cấp:\n#{notes}\n\nBạn có muốn tải về và cập nhật ngay không?"
        return unless UI.messagebox(msg, MB_YESNO) == IDYES
        tmp_dir = Sketchup.temp_dir.tr('\\', '/')
        tmp_zip = File.join(tmp_dir, 't2ms_net_update.zip')
        ext_dir = File.join(tmp_dir, 't2ms_net_extracted')
        File.binwrite(tmp_zip, self.tai_noi_dung_https(zip_url))
        self.ps_unzip(tmp_zip, ext_dir)
        target_dir = File.expand_path(__dir__)
        Dir.glob(File.join(ext_dir, '**', '*.rb')).each do |f|
          bn = File.basename(f)
          if bn == 'T2MS_Mod.rb' && File.exist?(File.join(target_dir, 'T2MS_Mod_Main.rb'))
            bn = 'T2MS_Mod_Main.rb'
          end
          dest = File.join(target_dir, bn)
          File.delete(dest) if File.exist?(dest)
          FileUtils.cp(f, dest)
        end
        load File.join(target_dir, 'T2MS_Mod_Updater.rb')
        load File.join(target_dir, 'T2MS_Mod_Lib.rb') if File.exist?(File.join(target_dir, 'T2MS_Mod_Lib.rb'))
        ['T2MS_Mod_Main.rb', 'T2MS_Mod.rb'].each do |m|
          mp = File.join(target_dir, m)
          load mp if File.exist?(mp)
        end
        self.bao_trang_thai_nut_update(false, new_ver)
        UI.messagebox("Cập nhật thành công lên phiên bản #{new_ver}!")
      rescue => e
        UI.messagebox("Lỗi cập nhật:\n#{e.message}") unless silent
      end
    end

  def self.xuat_ban_update_admin
  next_ver = CURRENT_VERSION.sub(/(\d+)$/) { |m| format("%0#{m.length}d", m.to_i + 1) }
  next_ver = 'Ver 1.06' if next_ver == CURRENT_VERSION
  prompts  = ['Số phiên bản phát hành mới:', 'Ghi chú nội dung nâng cấp:', 'Thư mục xuất gói cập nhật:', 'Lưu file cài đặt .rbz theo version:']
  defaults = [next_ver, 'Nâng cấp tính năng mới và tối ưu hiệu năng.', self.admin_release_dir, 'Có']
  list     = ['', '', '', 'Có|Không']
  res = UI.inputbox(prompts, defaults, list, 'Admin - Xuất bản cập nhật T2MS-Mod')
  return unless res
  new_ver  = res.at(0).to_s.strip
  notes    = res.at(1).to_s.strip
  out_dir  = res.at(2).to_s.strip.tr('\\', '/')
  save_rbz = (res.at(3).to_s.strip == 'Có')
  return if new_ver.empty? || out_dir.empty?

  p_dir  = File.expand_path(__dir__)
  upd_fp = File.join(p_dir, 'T2MS_Mod_Updater.rb')
  main_f = File.exist?(File.join(p_dir, 'T2MS_Mod_Main.rb')) ? File.join(p_dir, 'T2MS_Mod_Main.rb') : File.join(p_dir, 'T2MS_Mod.rb')

  uc_txt = File.read(upd_fp, encoding: 'UTF-8')
  uc_txt.sub!(/CURRENT_VERSION\s*=\s*'.*?'/, "CURRENT_VERSION    = '#{new_ver}'")
  File.write(upd_fp, uc_txt, encoding: 'UTF-8')

  mc_txt = File.read(main_f, encoding: 'UTF-8')
  mc_txt.gsub!(/Ver \d+\.\d+/, new_ver)
  File.write(main_f, mc_txt, encoding: 'UTF-8')

  load upd_fp
  load main_f

  FileUtils.mkdir_p(out_dir)
  tmp_dir = Sketchup.temp_dir.tr('\\', '/')
  pub_tmp = File.join(tmp_dir, 't2ms_pub_zip_tmp')
  FileUtils.rm_rf(pub_tmp)
  FileUtils.mkdir_p(pub_tmp)
  ['T2MS_Mod_Main.rb', 'T2MS_Mod.rb', 'T2MS_Mod_Lib.rb', 'T2MS_Mod_Updater.rb'].each do |f|
    src = File.join(p_dir, f)
    FileUtils.cp(src, File.join(pub_tmp, f)) if File.exist?(src)
  end
  zip_p = File.join(out_dir, 'T2MS_Mod_Update.zip')
  self.ps_zip(pub_tmp, zip_p)

  zip_raw_url = DEFAULT_UPDATE_URL.sub(/version\.json$/, 'T2MS_Mod_Update.zip')
  meta = { 'version' => new_ver, 'notes' => notes, 'zip_url' => zip_raw_url }
  File.write(File.join(out_dir, 'version.json'), JSON.pretty_generate(meta), encoding: 'UTF-8')

  rbz_info = ''
  if save_rbz
    ver_slug = new_ver.gsub(/[^0-9A-Za-z._-]/, '')
    ver_num  = new_ver.gsub(/[^0-9.]/, '')
    ver_num  = '1.06' if ver_num.empty?
    pkg_tmp  = File.join(tmp_dir, 'T2MS_Mod_Admin_RBZ')
    mod_sub  = File.join(pkg_tmp, 'T2MS-Mod')
    FileUtils.rm_rf(pkg_tmp)
    FileUtils.mkdir_p(mod_sub)

    # Chép mã nguồn chính vào T2MS-Mod/
    File.write(File.join(mod_sub, 'T2MS_Mod_Main.rb'), File.read(main_f, encoding: 'UTF-8'), encoding: 'UTF-8')
    ['T2MS_Mod_Lib.rb', 'T2MS_Mod_Updater.rb'].each do |f|
      s = File.join(p_dir, f)
      File.write(File.join(mod_sub, f), File.read(s, encoding: 'UTF-8'), encoding: 'UTF-8') if File.exist?(s)
    end

    # Chép toàn bộ thư mục dữ liệu (Library, SKP, Thumbs) và JSON vào gọn trong T2MS-Mod/
    plg_root = Sketchup.find_support_file('Plugins').tr('\\', '/')
    ['T2MS_Mod_Library', 'T2MS_Mod_SKP', 'T2MS_Mod_Thumbs'].each do |sub_folder|
      src_f = Dir.exist?(File.join(p_dir, sub_folder)) ? File.join(p_dir, sub_folder) : File.join(plg_root, sub_folder)
      if Dir.exist?(src_f)
        dst_f = File.join(mod_sub, sub_folder)
        FileUtils.mkdir_p(dst_f)
        Dir.glob(File.join(src_f, '**', '*')).each do |item|
          next if File.directory?(item)
          rel = item.sub("#{src_f}/", '')
          FileUtils.mkdir_p(File.dirname(File.join(dst_f, rel)))
          FileUtils.cp(item, File.join(dst_f, rel))
        end
      end
    end

    ['T2MS_Mod_Presets.json', 'T2MS_Mod_Library.json'].each do |jf|
      src_j = File.exist?(File.join(p_dir, jf)) ? File.join(p_dir, jf) : File.join(plg_root, jf)
      FileUtils.cp(src_j, File.join(mod_sub, jf)) if File.exist?(src_j)
    end

    # Tạo tệp gốc T2MS-Mod.rb chuẩn SketchUp Extension
    ldr = [
      "require 'sketchup.rb'",
      "require 'extensions.rb'",
      "",
      "module TuAoThamSo",
      "  unless file_loaded?(__FILE__)",
      "    ext = SketchupExtension.new('T2MS-Mod - Thiết kế tủ áo tham số', 'T2MS-Mod/T2MS_Mod_Main')",
      "    ext.description = 'Công cụ thiết kế tủ áo tham số, chia khoang, chỉnh tấm, thư viện mẫu và cập nhật trực tuyến.'",
      "    ext.version     = '#{ver_num}'",
      "    ext.copyright   = 'T2MS-Mod © 2026'",
      "    ext.creator     = 'T2MS-Mod'",
      "    Sketchup.register_extension(ext, true)",
      "    file_loaded(__FILE__)",
      "  end",
      "end"
    ].join("\n")
    File.write(File.join(pkg_tmp, 'T2MS-Mod.rb'), ldr, encoding: 'UTF-8')

    rbz_dir = File.dirname(out_dir)
    zip_tmp = File.join(rbz_dir, "T2MS-Mod_#{ver_slug}.zip")
    rbz_out = File.join(rbz_dir, "T2MS-Mod_#{ver_slug}.rbz")
    File.delete(rbz_out) if File.exist?(rbz_out)
    self.ps_zip(pkg_tmp, zip_tmp)
    File.rename(zip_tmp, rbz_out) if File.exist?(zip_tmp)
    rbz_info = "\n- File cài đặt chuẩn (.rbz): #{rbz_out}" if File.exist?(rbz_out)
  end

  UI.messagebox("Đã xuất bản thành công gói #{new_ver}!#{rbz_info}\n- Gói GitHub tại: #{out_dir}")
  system(%Q(explorer "#{out_dir.tr('/', '\\')}"))
end

end