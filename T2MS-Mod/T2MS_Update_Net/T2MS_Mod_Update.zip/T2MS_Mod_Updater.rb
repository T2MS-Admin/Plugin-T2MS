require 'json'
require 'net/http'
require 'openssl'
require 'uri'
require 'fileutils'
require 'zip'

module TuAoThamSo
  CURRENT_VERSION    = 'Ver 1.01'
  DEFAULT_UPDATE_URL = 'https://raw.githubusercontent.com/T2MS-Admin/Plugin-T2MS/main/T2MS-Mod/T2MS_Update_Net/version.json'
  ADMIN_RELEASE_DIR  = (Dir.exist?('D:/T2MS-Admin/T2MS-Mod') ? 'D:/T2MS-Admin/T2MS-Mod/T2MS_Update_Net' : File.join(Dir.home, 'Desktop', 'T2MS_Update_Net'))

  ADMIN_PIN = '2026'
  def self.la_may_admin?
    return true if Dir.exist?('D:/T2MS-Admin/T2MS-Mod')
    Sketchup.read_default('T2MSMod', 'is_admin_unlocked', false) == true
  end
  def self.xac_thuc_admin_va_xuat_ban
    unless self.la_may_admin?
      res = UI.inputbox(['Nhập mã PIN Admin để mở khóa quyền xuất bản:'], [''], 'Xác thực Admin T2MS-Mod')
      return unless res
      if res.at(0).to_s.strip == ADMIN_PIN
        Sketchup.write_default('T2MSMod', 'is_admin_unlocked', true)
      else
        UI.messagebox('Sai mã PIN Admin!')
        return
      end
    end
    self.xuat_ban_update_admin
  end

  def self.cau_hinh_update_path
    File.join(File.dirname(__FILE__), 'T2MS_Mod_Library', 'update_source.json')
  end

  def self.lay_nguon_cap_nhat
    p = self.cau_hinh_update_path
    if File.exist?(p)
      data = JSON.parse(File.read(p, encoding: 'UTF-8')) rescue {}
      url = data['source_url'].to_s.strip
      return url unless url.empty?
    end
    DEFAULT_UPDATE_URL
  end

  def self.thiet_lap_nguon_cap_nhat
    cur = self.lay_nguon_cap_nhat
    res = UI.inputbox(['Nhập Link HTTPS (version.json) hoặc Đường dẫn thư mục cập nhật:'], [cur], 'Cài đặt nguồn cập nhật T2MS-Mod')
    return unless res
    src = res.at(0).to_s.strip
    FileUtils.mkdir_p(File.dirname(self.cau_hinh_update_path))
    File.write(self.cau_hinh_update_path, JSON.pretty_generate({ 'source_url' => src }), encoding: 'UTF-8')
    UI.messagebox('Đã lưu nguồn cập nhật thành công!')
  end

  def self.tai_noi_dung_https(url_str, limit = 5)
    raise 'Quá nhiều lần chuyển hướng URL!' if limit <= 0
    uri = URI.parse(url_str.strip)
    http = Net::HTTP.new(uri.host, uri.port)
    if uri.scheme == 'https'
      http.use_ssl = true
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    end
    http.open_timeout = 8
    http.read_timeout = 15
    req = Net::HTTP::Get.new(uri.request_uri)
    req['User-Agent'] = 'T2MS-Mod-Updater'
    res = http.request(req)
    case res
    when Net::HTTPSuccess then res.body
    when Net::HTTPRedirection then self.tai_noi_dung_https(res['location'], limit - 1)
    else raise "Lỗi kết nối máy chủ: #{res.code} #{res.message}"
    end
  end

  def self.kiem_tra_cap_nhat_ngam
    return if @da_check_update_phien_nay
    @da_check_update_phien_nay = true
    UI.start_timer(1.5, false) { self.kiem_tra_va_cap_nhat_plugin(true) }
  end

  def self.kiem_tra_va_cap_nhat_plugin(silent = false)
    src = self.lay_nguon_cap_nhat
    if src.empty?
      return if silent
      self.thiet_lap_nguon_cap_nhat
      src = self.lay_nguon_cap_nhat
      return if src.empty?
    end
    begin
      if src.start_with?('http://', 'https://')
        raw_json = self.tai_noi_dung_https(src).force_encoding('UTF-8')
        meta     = JSON.parse(raw_json)
        new_ver  = meta['version'].to_s.strip
        zip_url  = meta['zip_url'].to_s.strip
        notes    = meta['notes'].to_s.strip
        if new_ver.empty? || new_ver == CURRENT_VERSION
          @dialog.execute_script("setUpdateAvailable(false, '#{CURRENT_VERSION}')") if @dialog && @dialog.visible?
          UI.messagebox("Bạn đang dùng phiên bản mới nhất (#{CURRENT_VERSION})!") unless silent
          return
        end
        @dialog.execute_script("setUpdateAvailable(true, '#{new_ver}')") if @dialog && @dialog.visible?
        if silent
          return
        end
        if false
          UI.messagebox("Bạn đang dùng phiên bản mới nhất (#{CURRENT_VERSION})!") unless silent
          return
        end
        return unless UI.messagebox("Đã có bản cập nhật mới: #{new_ver}\nPhiên bản hiện tại: #{CURRENT_VERSION}\n\nNội dung nâng cấp:\n#{notes}\n\nBạn có muốn tải về và cập nhật ngay không?", MB_YESNO) == IDYES
        tmp_zip = File.join(Sketchup.temp_dir, 't2ms_net_update.zip')
        File.binwrite(tmp_zip, self.tai_noi_dung_https(zip_url))
      else
        dir = src.tr('\\', '/')
        ver_file = File.join(dir, 'version.json')
        zip_file = File.join(dir, 'T2MS_Mod_Update.zip')
        unless File.exist?(ver_file) && File.exist?(zip_file)
          UI.messagebox("Không tìm thấy tệp cập nhật tại:\n#{dir}") unless silent
          return
        end
        meta     = JSON.parse(File.read(ver_file, encoding: 'UTF-8'))
        new_ver  = meta['version'].to_s.strip
        notes    = meta['notes'].to_s.strip
        if new_ver.empty? || new_ver == CURRENT_VERSION
          UI.messagebox("Bạn đang dùng phiên bản mới nhất (#{CURRENT_VERSION})!") unless silent
          return
        end
        return unless UI.messagebox("Đã có bản cập nhật mới: #{new_ver}\nPhiên bản hiện tại: #{CURRENT_VERSION}\n\nNội dung nâng cấp:\n#{notes}\n\nCập nhật ngay?", MB_YESNO) == IDYES
        tmp_zip = zip_file
      end
      target_dir = File.dirname(__FILE__)
      Zip::File.open(tmp_zip) do |zf|
        zf.each do |entry|
          next if entry.directory?
          dest = File.join(target_dir, entry.name)
          FileUtils.mkdir_p(File.dirname(dest))
          File.delete(dest) if File.exist?(dest)
          entry.extract(dest)
        end
      end
      load File.join(target_dir, 'T2MS_Mod_Updater.rb')
      load File.join(target_dir, 'T2MS_Mod_Lib.rb')
      load File.join(target_dir, 'T2MS_Mod.rb')
      @dialog.execute_script("setUpdateAvailable(false, '#{new_ver}')") if @dialog && @dialog.visible?; UI.messagebox("Cập nhật thành công lên phiên bản #{new_ver}!")
    rescue => e
      UI.messagebox("Lỗi cập nhật:\n#{e.message}") unless silent
    end
  end

  def self.xuat_ban_update_admin
    next_ver = CURRENT_VERSION.sub(/(\d+)$/) { |m| format("%0#{m.length}d", m.to_i + 1) }
    next_ver = 'T2MS-1.02' if next_ver == CURRENT_VERSION
    res = UI.inputbox(['Số phiên bản phát hành mới:', 'Ghi chú nội dung nâng cấp:', 'Thư mục xuất gói cập nhật:'], [next_ver, 'Nâng cấp tính năng mới và tối ưu hiệu năng.', ADMIN_RELEASE_DIR], 'Admin - Xuất bản cập nhật T2MS-Mod')
    return unless res
    new_ver = res.at(0).to_s.strip
    notes   = res.at(1).to_s.strip
    out_dir = res.at(2).to_s.strip.tr('\\', '/')
    return if new_ver.empty? || out_dir.empty?
    p_dir  = File.dirname(__FILE__)
    upd_f  = File.join(p_dir, 'T2MS_Mod_Updater.rb')
    main_f = File.join(p_dir, 'T2MS_Mod.rb')
    uc = File.read(upd_f, encoding: 'UTF-8')
    uc.sub!(/CURRENT_VERSION\s*=\s*'.*?'/, "CURRENT_VERSION    = '#{new_ver}'")
    File.write(upd_f, uc, encoding: 'UTF-8')
    mc = File.read(main_f, encoding: 'UTF-8')
    mc.gsub!(/T2MS-\d+\.\d+/, new_ver)
    File.write(main_f, mc, encoding: 'UTF-8')
    load upd_f
    load main_f
    FileUtils.mkdir_p(out_dir)
    zip_p = File.join(out_dir, 'T2MS_Mod_Update.zip')
    File.delete(zip_p) if File.exist?(zip_p)
    Zip::File.open(zip_p, create: true) do |zf|
      ['T2MS_Mod.rb', 'T2MS_Mod_Lib.rb', 'T2MS_Mod_Updater.rb'].each do |f|
        src = File.join(p_dir, f)
        if File.exist?(src)
          txt = File.read(src, encoding: 'UTF-8')
          txt.gsub!('File.dirname(__FILE__)', 'File.dirname(__FILE__)')
          txt.gsub!("File.dirname(__FILE__)", 'File.dirname(__FILE__)')
          zf.get_output_stream(f) { |os| os.write(txt) }
        end
      end
    end
    zip_raw_url = DEFAULT_UPDATE_URL.sub(/version\.json$/, 'T2MS_Mod_Update.zip')
    meta = { 'version' => new_ver, 'notes' => notes, 'zip_url' => zip_raw_url }
    File.write(File.join(out_dir, 'version.json'), JSON.pretty_generate(meta), encoding: 'UTF-8')
    UI.messagebox("Đã xuất bản thành công gói #{new_ver}!\nHãy kéo thả 2 tệp trong thư mục vừa mở lên GitHub.")
    system("explorer \"#{out_dir.tr('/', '\\')}\"")
  end
end