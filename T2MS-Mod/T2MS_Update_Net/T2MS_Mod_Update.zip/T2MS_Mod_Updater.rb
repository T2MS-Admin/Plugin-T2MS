require 'json'
require 'net/http'
require 'openssl'
require 'uri'
require 'fileutils'
require 'zip'

module TuAoThamSo
  CURRENT_VERSION = 'T2MS-1.01'
  # Dán link raw tới file version.json trên GitHub/Server của bạn vào đây để mặc định cho mọi máy:
  DEFAULT_UPDATE_URL = ''

  def self.cau_hinh_update_path
    File.join(File.dirname(__FILE__), 'T2MS_Mod_Library', 'update_source.json')
  end

  def self.lay_nguon_cap_nhat
    p = self.cau_hinh_update_path
    if File.exist?(p)
      data = JSON.parse(File.read(p, encoding: 'UTF-8')) rescue {}
      url = data['source_url'].to_s.strip
      return url unless url.empty?
    end
    DEFAULT_UPDATE_URL
  end

  def self.thiet_lap_nguon_cap_nhat
    cur = self.lay_nguon_cap_nhat
    res = UI.inputbox(['Nhập URL file version.json trên Internet (HTTPS):'], [cur], 'Cài đặt nguồn cập nhật Internet')
    return unless res
    src = res.at(0).to_s.strip
    FileUtils.mkdir_p(File.dirname(self.cau_hinh_update_path))
    File.write(self.cau_hinh_update_path, JSON.pretty_generate({ 'source_url' => src }), encoding: 'UTF-8')
    UI.messagebox('Đã lưu đường dẫn cập nhật Internet thành công!')
  end

  def self.tai_noi_dung_https(url_str, limit = 5)
    raise 'Quá nhiều lần chuyển hướng URL!' if limit <= 0
    uri = URI.parse(url_str.strip)
    http = Net::HTTP.new(uri.host, uri.port)
    if uri.scheme == 'https'
      http.use_ssl = true
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    end
    http.open_timeout = 10
    http.read_timeout = 20
    req = Net::HTTP::Get.new(uri.request_uri)
    req['User-Agent'] = 'T2MS-Mod-Updater'
    res = http.request(req)
    case res
    when Net::HTTPSuccess then res.body
    when Net::HTTPRedirection then self.tai_noi_dung_https(res['location'], limit - 1)
    else raise "Lỗi kết nối máy chủ: #{res.code} #{res.message}"
    end
  end

  def self.kiem_tra_va_cap_nhat_plugin
    src = self.lay_nguon_cap_nhat
    if src.empty?
      self.thiet_lap_nguon_cap_nhat
      src = self.lay_nguon_cap_nhat
      return if src.empty?
    end
    begin
      raw_json = self.tai_noi_dung_https(src).force_encoding('UTF-8')
      meta     = JSON.parse(raw_json)
      new_ver  = meta['version'].to_s.strip
      zip_url  = meta['zip_url'].to_s.strip
      notes    = meta['notes'].to_s.strip
      if new_ver.empty? || new_ver == CURRENT_VERSION
        UI.messagebox("Bạn đang dùng phiên bản mới nhất (#{CURRENT_VERSION})!")
        return
      end
      msg = "Đã có bản cập nhật mới: #{new_ver}\nPhiên bản hiện tại: #{CURRENT_VERSION}\n\nNội dung nâng cấp:\n#{notes}\n\nBạn có muốn tải về và cập nhật ngay không?"
      return unless UI.messagebox(msg, MB_YESNO) == IDYES
      tmp_zip = File.join(Sketchup.temp_dir, 't2ms_net_update.zip')
      File.binwrite(tmp_zip, self.tai_noi_dung_https(zip_url))
      target_dir = File.dirname(__FILE__)
      Zip::File.open(tmp_zip) do |zf|
        zf.each do |entry|
          next if entry.directory?
          dest = File.join(target_dir, entry.name)
          FileUtils.mkdir_p(File.dirname(dest))
          File.delete(dest) if File.exist?(dest)
          entry.extract(dest)
        end
      end
      load File.join(target_dir, 'T2MS_Mod_Updater.rb')
      load File.join(target_dir, 'T2MS_Mod_Lib.rb')
      load File.join(target_dir, 'T2MS_Mod.rb')
      UI.messagebox("Cập nhật qua Internet thành công lên phiên bản #{new_ver}!")
    rescue => e
      UI.messagebox("Không thể cập nhật qua Internet:\n#{e.message}")
    end
  end
end